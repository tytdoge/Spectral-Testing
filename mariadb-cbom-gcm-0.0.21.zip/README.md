# MariaDB cryptographic discovery 0.0.21

Based on the supplied v0.0.15 plugin, retaining Bug 1's it_asset_uri field,
including the reviewed Bug 2 classification change, and repairing Bug 3.
Target: GCM v2.0.3.0 with standard IANA cipher names. Original user packages
and reports remain unchanged.

## Flow

MariaDB host / SSH -> target TLS expansion -> CycloneDX 1.6 CBOM -> flat rows
-> GCM transformer / ingest.

Only crypto_asset_details_*.json is declared in outputFiles. Source cbom_*.json
files are saved for audit and listed in status details, without also ingesting
them through the native CBOM importer.

## Bug 3

- Expand expressions on the target, never on the worker. Compare MariaDB's
  reported OpenSSL version with the target CLI's runtime library version.
- Resolve configured TLS versions separately, including TLS 1.3 ciphersuites.
- Normalise aliases with a pinned OpenSSL 3.5.3 standard-name catalogue. It
  contains 201 known names, not the entire IANA registry. Arbitrary TLS_ and
  SSL_CK_ prefixes are not accepted as name validation.
- Keep HIGH:!aNULL:!MD5:!3DES as configuration evidence; it is never a suite name.
- Populate each CBOM protocol's cipherSuites and dependency edges. Protocol rows
  carry ciphers_available and a JSON transport field, decoded by the existing
  JavaScript custom-function convention into a GCM string array.
- Remove the mapping that put TLSv1.2 / TLSv1.3 in cipher_suite. Do not emit blank
  cipher rows; historical expressions become tls-configuration audit records.
- Save source CBOMs and report partial/unresolved TLS discovery in diagnostics.

MariaDB 10.5.29 and 10.11.6 default behavior was checked against their source:
10.5.29 applies ssl_cipher to both setters; 10.11.6 invokes the legacy setter
only when the TLS 1.3 setter fails. A setter not successfully applied retains
its library defaults. Unknown releases do not receive this default inference.
Explicit settings take precedence. Ssl_cipher_list is a fallback labelled
potentially partial: the status callback can return a bounded connection list.

Results represent configured/supported policy, not proof that every suite can
negotiate with the host's certificate. No active TLS handshake enumeration is
performed. Other backends, library mismatches and missing unknown defaults are
reported unresolved instead of being guessed.

## Bug 2

Algorithms remain category=algorithm with their primitive, source, functions
and explicit references. Certificate/key fields are retained. SHA-1 evidence
is preserved rather than removed to make the cipher report empty.

There is no standalone algorithm Inventory mapping in the supplied transformer.
Algorithm rows remain in CBOM/flat audit data; this release does not invent an
algorithms yield. Such Inventory mapping requires a confirmed GCM object schema.

## Requirements and validation

Original vendor dependencies are retained. The target uses Bash, awk and OpenSSL;
no new target Python dependency or runtime catalogue download is introduced.
TLS 1.3 needs a supporting target library/CLI.

Verified locally: 31 regression cases, collector self-test (components=20),
Python/JSON/YAML syntax, rendered Bash, native OpenSSL expansion, aliases and
exclusions, version isolation, default behavior, CBOM edges, rows, transformer
JavaScript projection, collection-prefix execution and source-CBOM output.

Not performed: a live user-host scan, proprietary GCM transformer runner, or
GCM v2.0.3.0 ingest/Inventory validation. The protocol mapping emits IANA strings
as an array; confirm appliance compatibility with the native runner and a fresh
scan. Local OpenSSL tests used simulated MariaDB metadata, not the user's host.

Local check:

    python3 -B src/discovery/lib/mariadb_cbom_ssh.py --self-test

On a machine with the matching GCM toolkit:

    plugin-toolkit test transformations -i crypto_asset_details_HOST_RUN.json -t transformation/discovery/transform_discover.json -o ./dest-reports

Then inspect actual ingest and protocol detail. Historical user reports contain
no expanded suite list, so a fresh discovery run is required after installation.

See PROVENANCE.json for source URLs and SHA-256 hashes. Vendor bytes are unchanged.
