#!/usr/bin/env python3
"""SSH discovery entry used by the Guardium playbook.

Connection fields match MariaDB plug-in 1.0.3: password or in-memory PEM,
and sudo either passwordless (sudo -n) or with a sudo password (sudo -S).
The file written for the transform is the plain list from the 0.0.4 collector.
"""

from __future__ import annotations

import argparse
import io
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))

import mariadb_cbom_ssh as collector  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Collect MariaDB crypto assets and write the plain list")
    parser.add_argument("--config", required=True)
    parser.add_argument("--flat-output", required=True)
    parser.add_argument("--cbom-output", help="Optional source CBOM audit file; not a GCM transformation input")
    args = parser.parse_args(argv)
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    hostname = str(config.get("hostname") or "").strip()
    if not hostname:
        print("error:hostname is required", file=sys.stderr)
        return 1
    try:
        transcript = _collect(config)
        evidence = collector.evidence_from_transcript(transcript, hostname)
        document = collector.build_upload_cbom(evidence, hostname)
        rows = collector.discovery_from_cbom(document)
    except Exception as exc:  # noqa: BLE001 - the playbook still publishes the host row
        fallback = _server_row(hostname)
        _apply_profile(fallback, config)
        _write(args.flat_output, [fallback])
        print(f"error:{type(exc).__name__}: {exc}", file=sys.stderr)
        return 0
    if not any(row.get("category") == "it-asset" and row.get("hostname") for row in rows):
        rows.insert(0, _server_row(hostname))
    for row in rows:
        if row.get("category") == "it-asset":
            _apply_profile(row, config)
    if args.cbom_output:
        _write(args.cbom_output, document)
    _write(args.flat_output, rows)
    resolution = evidence.get("tls_suite_resolution") or {}
    if resolution.get("status") in {"unresolved", "partial"} and (evidence.get("tls_versions") or (evidence.get("ssl_paths") or {}).get("ssl_cipher")):
        print("warning:TLS suite discovery " + resolution["status"] + ": " + "; ".join(resolution.get("diagnostics", [])), file=sys.stderr)
    crypto = sum(1 for row in rows if row.get("category") != "it-asset")
    print(f"ok rows={crypto} host={hostname}")
    return 0


def _server_row(hostname: str) -> dict:
    return {"category": "it-asset", "hostname": hostname, "uri": hostname, "asset_type": "Database"}


# Typed on the connection form. Copied only when the operator entered a value.
# Names are the IT-asset fields the inventory export and IBM association properties use.
_PROFILE_FIELDS = (
    ("businessImpact", "mission_criticality"),
    ("internetFacing", "internet_facing"),
    ("owner", "owner"),
    ("techContacts", "tech_contacts"),
    ("network", "network"),
    ("environment", "environment"),
    ("location", "location"),
)


def _apply_profile(row: dict, config: dict) -> None:
    for source, dest in _PROFILE_FIELDS:
        value = str(config.get(source) or "").strip()
        if value:
            row[dest] = value


def _collect(config: dict) -> str:
    client = _connect(config)
    use_sudo = _truthy(config.get("useSudo"))
    sudo_password = str(config.get("sudoPassword") or "")
    timeout = _bounded_int(config.get("commandTimeout"), default=180, low=30, high=900)
    try:
        command = collector.remote_command(use_sudo, sudo_password if use_sudo else "")
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
        if use_sudo and sudo_password:
            stdin.write(sudo_password + "\n")
        stdin.write(collector.render_remote())
        stdin.flush()
        stdin.channel.shutdown_write()
        output, error = _read_channel(stdout, stderr, timeout)
    finally:
        client.close()
    secrets = [str(config.get("sshPassword") or ""), sudo_password]
    output = _redact(output, secrets)
    error = _redact(error, secrets)
    if "##END assets##" not in output:
        if use_sudo and _sudo_rejected(error):
            detail = _sudo_detail(error)
            raise RuntimeError(
                "sudo rejected the request. Enter the account's sudo password in Sudo password, "
                "or grant NOPASSWD. sudo said: " + detail
            )
        detail = error.strip().splitlines()[-1] if error.strip() else "collector produced no asset section"
        raise RuntimeError(detail)
    return output


def _connect(config: dict):
    """Open a Paramiko session from a password or an in-memory PEM key."""
    import paramiko

    hostname = str(config.get("hostname") or "")
    if not hostname:
        raise ValueError("hostname is required")
    port = _bounded_int(config.get("sshPort"), default=22, low=1, high=65535)
    username = str(config.get("sshUser") or "")
    if not username:
        raise ValueError("sshUser is required")
    password = str(config.get("sshPassword") or "") or None
    private_key = _load_private_key(str(config.get("sshPrivateKey") or ""), str(config.get("sshKeyPassphrase") or ""))
    client = paramiko.SSHClient()
    known_hosts = str(config.get("sshKnownHosts") or "").strip()
    known_path = ""
    if known_hosts:
        import tempfile

        handle = tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8")
        handle.write(known_hosts)
        handle.close()
        known_path = handle.name
        client.load_host_keys(known_path)
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
    else:
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname,
            port=port,
            username=username,
            password=password,
            pkey=private_key,
            timeout=20,
            banner_timeout=20,
            auth_timeout=20,
            look_for_keys=False,
            allow_agent=False,
        )
    finally:
        if known_path:
            import os

            os.unlink(known_path)
    return client


def _load_private_key(pem: str, passphrase: str):
    if not pem.strip():
        return None
    import paramiko

    secret = passphrase or None
    buffer = io.StringIO(pem)
    errors = []
    for loader in (
        paramiko.Ed25519Key.from_private_key,
        paramiko.RSAKey.from_private_key,
        paramiko.ECDSAKey.from_private_key,
    ):
        buffer.seek(0)
        try:
            return loader(buffer, password=secret)
        except Exception as exc:  # noqa: BLE001 - try the next key type
            errors.append(str(exc))
    raise ValueError("SSH private key could not be parsed: " + "; ".join(errors))


def _read_channel(stdout: object, stderr: object, timeout: int) -> tuple[str, str]:
    channel = stdout.channel  # type: ignore[attr-defined]
    out_parts: list[bytes] = []
    err_parts: list[bytes] = []
    deadline = time.monotonic() + max(int(timeout), 1)
    while True:
        progressed = False
        if channel.recv_ready():
            out_parts.append(channel.recv(65536))
            progressed = True
        if channel.recv_stderr_ready():
            err_parts.append(channel.recv_stderr(65536))
            progressed = True
        if channel.exit_status_ready() and not channel.recv_ready() and not channel.recv_stderr_ready():
            break
        if time.monotonic() >= deadline:
            break
        if not progressed:
            time.sleep(0.05)
    output = b"".join(out_parts).decode("utf-8", errors="replace")
    error = b"".join(err_parts).decode("utf-8", errors="replace")
    return output, error


def _sudo_rejected(error: str) -> bool:
    lowered = error.lower()
    markers = (
        "password is required",
        "a terminal is required",
        "sorry, try again",
        "incorrect password",
        "no password was provided",
        "authentication failure",
    )
    return any(marker in lowered for marker in markers)


def _sudo_detail(error: str) -> str:
    lines = [line.strip() for line in error.splitlines() if line.strip()]
    if not lines:
        return "sudo exited without running the collector"
    return lines[-1][:240]


def _redact(text: str, secrets: list[str]) -> str:
    cleaned = text
    for secret in secrets:
        if secret:
            cleaned = cleaned.replace(secret, "<redacted>")
    return cleaned


def _bounded_int(value: object, *, default: int, low: int, high: int) -> int:
    try:
        number = int(str(value))
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def _truthy(value: object) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _write(path: str, document: object) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(document, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        raise SystemExit(0)
    except Exception as exc:  # noqa: BLE001 - the playbook captures stderr
        print(f"error:{type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
