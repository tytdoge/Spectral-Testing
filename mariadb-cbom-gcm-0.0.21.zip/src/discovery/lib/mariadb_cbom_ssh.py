#!/usr/bin/env python3
"""Read-only MariaDB SSH collector that writes a CycloneDX CBOM.

The script signs in with SSH, reads MariaDB certificates, key metadata,
TLS protocols, cipher suites, and SQL or plugin code assets, then writes
the CycloneDX 1.6 document IBM Guardium Cryptography Manager imports from
Discovery > Import profiles > CBOM report.

Keep this file together with tls_suites.py and tls_cipher_catalog.py.
It does not install or call a GCM discovery plugin. Private-key bodies and
password values are not written into the CBOM.

Passwords are read from the environment when the matching flag is omitted:

    MARIADB_SSH_PASSWORD
    MARIADB_SUDO_PASSWORD
    MARIADB_MYSQL_PASSWORD
"""

from __future__ import annotations

import argparse
import ipaddress
import json
import os
import re
import shlex
import subprocess
import sys
import tempfile
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

_TLS_HELPER_DIR = str(Path(__file__).resolve().parent)
if _TLS_HELPER_DIR not in sys.path:
    sys.path.insert(0, _TLS_HELPER_DIR)
import tls_suites as tls_inventory

PLUGIN_VERSION = "0.0.21"

# Longer tokens first when spans start at the same index.
_TOKEN_SPECS = [
    ("X25519MLKEM768", r"X25519MLKEM768", "HYBRID_PQC"),
    ("SecP256r1MLKEM768", r"SecP256r1MLKEM768", "HYBRID_PQC"),
    ("ML-KEM", r"ML-?KEM(?:-?\d+)?", "QUANTUM_RESISTANT"),
    ("ML-DSA", r"ML-?DSA(?:-?\d+)?", "QUANTUM_RESISTANT"),
    ("SLH-DSA", r"SLH-?DSA(?:-?\d+)?", "QUANTUM_RESISTANT"),
    ("TLSv1.0", r"TLSv1\.0", "CLASSICAL_WEAK"),
    ("TLSv1.1", r"TLSv1\.1", "CLASSICAL_WEAK"),
    ("TLSv1.2", r"TLSv1\.2", "INFORMATIONAL"),
    ("TLSv1.3", r"TLSv1\.3", "INFORMATIONAL"),
    ("SSLv3", r"SSLv[23]", "CLASSICAL_WEAK"),
    ("TLSv1.0", r"TLSv1(?!\.)", "CLASSICAL_WEAK"),
    ("ECDHE", r"ECDHE", "QUANTUM_VULNERABLE"),
    ("ECDSA", r"ECDSA", "QUANTUM_VULNERABLE"),
    ("Ed25519", r"ED25519", "QUANTUM_VULNERABLE"),
    ("DHE", r"DHE", "QUANTUM_VULNERABLE"),
    ("RSA", r"RSA", "QUANTUM_VULNERABLE"),
    ("X25519", r"X25519", "QUANTUM_VULNERABLE"),
    ("SM2", r"SM2", "QUANTUM_VULNERABLE"),
    ("AES-256", r"AES[_-]?256", "QUANTUM_RESISTANT"),
    ("AES-128", r"AES[_-]?128", "GROVER_REDUCED"),
    ("AES-CBC", r"AES_CBC", "INFORMATIONAL"),
    ("AES-CTR", r"AES_CTR", "INFORMATIONAL"),
    ("CHACHA20-POLY1305", r"CHACHA20", "QUANTUM_RESISTANT"),
    ("SHA-384", r"SHA-?384", "INFORMATIONAL"),
    ("SHA-512", r"SHA-?512", "INFORMATIONAL"),
    ("SHA-256", r"SHA-?256", "GROVER_REDUCED"),
    ("SHA-1", r"SHA-?1(?!\d)", "CLASSICAL_WEAK"),
    ("MD5", r"MD5", "CLASSICAL_WEAK"),
    ("3DES", r"3DES", "CLASSICAL_WEAK"),
    ("DES", r"(?<![A-Z0-9])DES(?![A-Z0-9])", "CLASSICAL_WEAK"),
    ("RC4", r"RC4", "CLASSICAL_WEAK"),
    ("SM4", r"SM4", "GROVER_REDUCED"),
    ("SM3", r"SM3", "GROVER_REDUCED"),
    ("SHA-1", r"(?<![A-Z0-9])SHA(?![A-Z0-9-])", "CLASSICAL_WEAK"),
]
_COMPILED = [(name, re.compile(pattern, re.I), risk) for name, pattern, risk in _TOKEN_SPECS]

POSTURE = {
    "CLASSICAL_WEAK": "PQC_UNSAFE",
    "QUANTUM_VULNERABLE": "PQC_UNSAFE",
    "GROVER_REDUCED": "GROVER_REDUCED",
    "HYBRID_PQC": "HYBRID",
    "QUANTUM_RESISTANT": "PQC_SAFE",
    "INFORMATIONAL": "INFORMATIONAL",
}


def classify_tokens(value: str) -> list[tuple[str, str]]:
    """Return (algorithm, risk) in left-to-right order. Overlaps are dropped."""
    text = value or ""
    if text.strip().lower() in {"mysql_native_password", "mysql_old_password"}:
        return [("SHA-1", "CLASSICAL_WEAK")]
    found: list[tuple[int, int, str, str]] = []
    for name, pattern, risk in _COMPILED:
        for match in pattern.finditer(text):
            found.append((match.start(), match.end(), name, risk))
    found.sort(key=lambda item: (item[0], -(item[1] - item[0])))
    chosen: list[tuple[str, str]] = []
    cursor = -1
    for start, end, name, risk in found:
        if start < cursor:
            continue
        chosen.append((name, risk))
        cursor = end
    return chosen



def _cipher_entries(cipher: str) -> list[str]:
    """Keep an OpenSSL list such as HIGH:!aNULL:!MD5:!3DES as one configured value."""
    text = (cipher or "").strip()
    if not text:
        return []
    pieces = [part for part in text.split(":") if part and not part.startswith("!") and not part.startswith("TLS_")]
    concrete = [part for part in pieces if re.search(r"AES|CHACHA|DES|RC4|ECDHE|DHE", part, re.I)]
    if concrete:
        return concrete
    return [text]


def _is_iana_cipher(name: str) -> bool:
    """Check a known standard name, rather than accepting any TLS_ prefix."""
    return str(name or "") in tls_inventory.IANA_NAMES


def _enabled_cipher_text(value: str) -> str:
    """Drop OpenSSL exclusions such as !MD5 and !3DES before naming algorithms."""
    return re.sub(r"![A-Za-z0-9_.:+-]+", " ", value or "")


def rows_from_evidence(evidence: dict, fixture: str = "live") -> list[dict]:
    rows: list[dict] = []

    def add(value: str, check_id: str, plane: str, category: str, source: str, status: str | None = None) -> None:
        for algorithm, risk in classify_tokens(value):
            row = {
                "fixture": fixture,
                "algorithm": algorithm,
                "risk": risk,
                "active": True,
                "plane": plane,
                "gcm_category": category,
                "checklist_id": check_id,
                "source_path": source,
            }
            if status:
                row["status"] = status
            rows.append(row)

    for version in evidence.get("tls_versions") or []:
        add(str(version), "MDB10-013", "transport", "protocol", "tls_version")
    for suite in (evidence.get("tls12_suites") or []) + (evidence.get("tls13_suites") or []):
        add(_enabled_cipher_text(str(suite)), "MDB10-014", "transport", "cipher_suite", "ssl_cipher")
    for group in evidence.get("groups") or []:
        add(str(group), "MDB10-016", "transport", "protocol", "negotiated_group")
    for cert in evidence.get("certificates") or []:
        if cert.get("pubkey_algorithm"):
            add(str(cert["pubkey_algorithm"]), "MDB10-010", "keys_certs", "certificate", cert.get("path", "certificate"))
        if cert.get("signature_algorithm"):
            add(str(cert["signature_algorithm"]), "MDB10-011", "hash_sign", "certificate", cert.get("path", "certificate"))
    for key in evidence.get("private_keys") or []:
        add(str(key.get("type", "")), "MDB10-012", "keys_certs", "key", key.get("path", "ssl_key"))
    if evidence.get("native_accounts"):
        add("mysql_native_password", "MDB10-044", "hash_sign", "key", "mysql.global_priv")
    if evidence.get("ed25519_accounts"):
        add("ed25519", "MDB10-045", "hash_sign", "key", "mysql.global_priv")
    for hit in evidence.get("sql_aes") or []:
        add("AES-128", "MDB10-047", "at_rest", "cipher_suite", hit.get("location", "routine"))
    for hit in evidence.get("sql_md5") or []:
        add("MD5", "MDB10-048", "hash_sign", "cipher_suite", hit.get("location", "routine"))
    for hit in evidence.get("sql_sha1") or []:
        add("SHA-1", "MDB10-049", "hash_sign", "cipher_suite", hit.get("location", "routine"))
    for hit in evidence.get("sql_sha2") or []:
        add(str(hit.get("algorithm", "SHA-256")), "MDB10-050", "hash_sign", "cipher_suite", hit.get("location", "routine"))
    for hit in evidence.get("sql_des") or []:
        add("DES", "MDB10-051", "at_rest", "cipher_suite", hit.get("location", "routine"))
    if evidence.get("file_key_algorithm"):
        add(str(evidence["file_key_algorithm"]), "MDB10-036", "at_rest", "cipher_suite", "file_key_management_encryption_algorithm")
    backup = evidence.get("backup") or {}
    if backup.get("algorithm"):
        add(str(backup["algorithm"]), "MDB10-055", "at_rest", "cipher_suite", backup.get("source", "mariabackup"))
    session = evidence.get("session_ssl") or {}
    if session.get("cipher"):
        add(str(session["cipher"]), "MDB10-033", "transport", "cipher_suite", "Ssl_cipher")
    if session.get("version"):
        add(str(session["version"]), "MDB10-033", "transport", "protocol", "Ssl_version")
    return rows



PROFILES = {
    "AES-256": {"primitive": "block-cipher", "parameterSetIdentifier": "256", "cryptoFunctions": ["encrypt", "decrypt"], "classicalSecurityLevel": 256, "nistQuantumSecurityLevel": 128},
    "AES-128": {"primitive": "block-cipher", "parameterSetIdentifier": "128", "cryptoFunctions": ["encrypt", "decrypt"], "classicalSecurityLevel": 128, "nistQuantumSecurityLevel": 64},
    "AES-CBC": {"primitive": "block-cipher", "mode": "cbc", "cryptoFunctions": ["encrypt", "decrypt"]},
    "AES-CTR": {"primitive": "block-cipher", "mode": "ctr", "cryptoFunctions": ["encrypt", "decrypt"]},
    "CHACHA20-POLY1305": {"primitive": "ae", "parameterSetIdentifier": "256", "cryptoFunctions": ["encrypt", "decrypt"]},
    "RSA": {"primitive": "pke", "cryptoFunctions": ["encrypt", "decrypt", "sign", "verify"]},
    "DHE": {"primitive": "key-agree", "cryptoFunctions": ["keyderive"]},
    "ECDHE": {"primitive": "key-agree", "cryptoFunctions": ["keyderive"]},
    "X25519": {"primitive": "key-agree", "curve": "X25519", "cryptoFunctions": ["keyderive"]},
    "ECDSA": {"primitive": "signature", "cryptoFunctions": ["sign", "verify"]},
    "Ed25519": {"primitive": "signature", "curve": "Ed25519", "cryptoFunctions": ["sign", "verify"]},
    "SM2": {"primitive": "signature", "cryptoFunctions": ["sign", "verify"]},
    "SM3": {"primitive": "hash", "parameterSetIdentifier": "256", "cryptoFunctions": ["digest"]},
    "SM4": {"primitive": "block-cipher", "parameterSetIdentifier": "128", "cryptoFunctions": ["encrypt", "decrypt"]},
    "SHA-1": {"primitive": "hash", "parameterSetIdentifier": "160", "cryptoFunctions": ["digest"]},
    "SHA-256": {"primitive": "hash", "parameterSetIdentifier": "256", "cryptoFunctions": ["digest"]},
    "SHA-384": {"primitive": "hash", "parameterSetIdentifier": "384", "cryptoFunctions": ["digest"]},
    "SHA-512": {"primitive": "hash", "parameterSetIdentifier": "512", "cryptoFunctions": ["digest"]},
    "MD5": {"primitive": "hash", "parameterSetIdentifier": "128", "cryptoFunctions": ["digest"]},
    "DES": {"primitive": "block-cipher", "parameterSetIdentifier": "56", "mode": "cbc", "cryptoFunctions": ["encrypt", "decrypt"]},
    "3DES": {"primitive": "block-cipher", "parameterSetIdentifier": "112", "cryptoFunctions": ["encrypt", "decrypt"]},
    "RC4": {"primitive": "stream-cipher", "cryptoFunctions": ["encrypt", "decrypt"]},
    "ML-KEM": {"primitive": "kem", "cryptoFunctions": ["encapsulate", "decapsulate"], "nistQuantumSecurityLevel": 1},
    "ML-DSA": {"primitive": "signature", "cryptoFunctions": ["sign", "verify"]},
    "SLH-DSA": {"primitive": "signature", "cryptoFunctions": ["sign", "verify"]},
    "X25519MLKEM768": {"primitive": "combiner", "parameterSetIdentifier": "768", "cryptoFunctions": ["keyderive", "encapsulate"]},
    "SecP256r1MLKEM768": {"primitive": "combiner", "parameterSetIdentifier": "768", "cryptoFunctions": ["keyderive", "encapsulate"]},
}


def _prop(name: str, value) -> dict:
    return {"name": name, "value": str(value)}


def _algorithm_properties(name: str) -> dict:
    profile = dict(PROFILES.get(name, {"primitive": "unknown", "cryptoFunctions": ["unknown"]}))
    return profile


def _is_protocol(name: str) -> bool:
    upper = name.upper()
    return upper.startswith("TLS") or upper.startswith("SSL")


class CbomBuilder:
    def __init__(self, hostname: str, service_uri: str):
        self.hostname = hostname or "localhost"
        self.service_uri = service_uri
        self.components: list[dict] = []
        self._seen: set[str] = set()
        self._algorithm_refs: dict[str, str] = {}

    def add(self, component: dict) -> str:
        ref = component["bom-ref"]
        if ref not in self._seen:
            self._seen.add(ref)
            self.components.append(component)
        return ref

    def algorithm(self, name: str, source: str = "", checklist_id: str = "", locations: list[str] | None = None) -> str:
        if _is_protocol(name):
            return self.protocol(name)
        ref = f"algorithm:{name}"
        properties = [_prop("serviceUri", self.service_uri)]
        if source:
            properties.append(_prop("sourcePath", source))
        if checklist_id:
            properties.append(_prop("checklistId", checklist_id))
        for location in locations or []:
            properties.append(_prop("evidenceLocation", location))
        self.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": ref,
                "name": name,
                "cryptoProperties": {
                    "assetType": "algorithm",
                    "algorithmProperties": _algorithm_properties(name),
                },
                "properties": properties,
            }
        )
        self._algorithm_refs[name] = ref
        return ref

    def protocol(self, version: str, suites: list[str] | None = None) -> str:
        ref = f"protocol:{version}"
        suite_entries = [{"name": suite} for suite in tls_inventory.canonical_names(suites or [])]
        existing = next((item for item in self.components if item.get("bom-ref") == ref), None)
        if existing is not None:
            current = existing["cryptoProperties"]["protocolProperties"].setdefault("cipherSuites", [])
            present = {item["name"] for item in current}
            current.extend(item for item in suite_entries if item["name"] not in present)
            return ref
        crypto: dict = {"assetType": "protocol", "protocolProperties": {"type": "tls", "version": version}}
        if suite_entries:
            crypto["protocolProperties"]["cipherSuites"] = suite_entries
        self.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": ref,
                "name": version,
                "cryptoProperties": crypto,
                "properties": [_prop("serviceUri", self.service_uri), _prop("assetKind", "protocol")],
            }
        )
        return ref

    def cipher_suite(self, name: str, source: str = "") -> str:
        name = tls_inventory.canonical_name(name)
        if not name:
            return ""
        ref = f"cipher-suite:{name}"
        algorithms = [self.algorithm(algorithm, source=source or "ssl_cipher", checklist_id="MDB10-014")
                      for algorithm, _risk in classify_tokens(name) if algorithm in PROFILES]
        self.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": ref,
                "name": name,
                "cryptoProperties": {
                    "assetType": "protocol",
                    "protocolProperties": {"type": "tls", "cipherSuites": [{"name": name, "algorithms": algorithms}]},
                },
                "properties": [
                    _prop("serviceUri", self.service_uri),
                    _prop("assetKind", "cipher-suite"),
                    _prop("sourcePath", source or "ssl_cipher"),
                ],
            }
        )
        return ref


def _port(evidence: dict) -> str:
    configured = str(evidence.get("server_port") or "")
    if configured.isdigit() and configured not in {"0", "1"}:
        return configured
    for listener in evidence.get("listeners") or []:
        if isinstance(listener, dict) and listener.get("port"):
            return str(listener["port"])
        match = re.search(r":(\d+)\b", str(listener))
        if match and match.group(1) not in {"0", "1"}:
            return match.group(1)
    return "3306"


def _locations(evidence: dict, *keys: str) -> list[str]:
    found = []
    for key in keys:
        for item in evidence.get(key) or []:
            if isinstance(item, dict) and item.get("location"):
                found.append(str(item["location"]))
    return found


_FILE_KEY_ID = re.compile(r"^[0-9]+$")
_FILE_KEY_HEX = re.compile(r"(?i)(?:^|[^0-9A-Fa-f])[0-9]+;[0-9A-Fa-f]{2,}(?![0-9A-Fa-f])")


def _file_key_algorithm_name(evidence: dict) -> str:
    """Return the server's file-key algorithm, or empty when it was not set."""
    alg_name = str(evidence.get("file_key_algorithm") or "").strip()
    if alg_name == "AES_CBC":
        return "AES-CBC"
    if alg_name == "AES_CTR":
        return "AES-CTR"
    return alg_name


def _reject_key_material(encoded: str) -> None:
    """Stop when a CBOM contains a private-key body or a file-key line."""
    if "PRIVATE KEY" in encoded or "-----BEGIN " in encoded or _FILE_KEY_HEX.search(encoded):
        raise RuntimeError("CBOM contains key material and was not written")


def build_cbom(evidence: dict, rows: list[dict], hostname: str = "", serial: str | None = None) -> dict:
    """Build a CycloneDX 1.6 CBOM of the MariaDB cryptographic assets."""
    host = hostname or evidence.get("hostname") or "localhost"
    service_uri = f"mysql://{host}:{_port(evidence)}"
    builder = CbomBuilder(host, service_uri)
    suite_groups = tls_inventory.suites_from_evidence(evidence)
    version = str(evidence.get("version") or "10")
    for row in rows:
        name = row.get("algorithm") or ""
        if not name or name.upper() in {"NONE", "CLEARTEXT"}:
            continue
        if _is_protocol(name):
            builder.protocol(name)
        else:
            builder.algorithm(name, source=row.get("source_path", ""), checklist_id=row.get("checklist_id", ""))
    for tls_version, suites in suite_groups.items():
        builder.protocol(tls_version, suites)
        for suite in suites:
            builder.cipher_suite(suite)
    for group in evidence.get("groups") or []:
        builder.algorithm(str(group), source="negotiated_group", checklist_id="MDB10-016")
    for cert in evidence.get("certificates") or []:
        pubkey = cert.get("pubkey_algorithm") or ""
        signature = cert.get("signature_algorithm") or ""
        pubkey_ref = builder.algorithm(pubkey, source=cert.get("path", ""), checklist_id="MDB10-010") if pubkey else ""
        # Signature strings such as sha256WithRSAEncryption are not a single profile name.
        # Keep the certificate link only when the signature text is itself a known algorithm.
        sig_ref = ""
        if signature in PROFILES:
            sig_ref = builder.algorithm(signature, source=cert.get("path", ""), checklist_id="MDB10-011")
        certificate_properties = {
            "subjectName": cert.get("subject") or cert.get("path") or "unknown",
            "issuerName": cert.get("issuer") or "unknown",
        }
        if cert.get("fingerprint"):
            certificate_properties["certificateExtension"] = f"fingerprint={cert['fingerprint']}"
        if pubkey_ref:
            certificate_properties["subjectPublicKeyRef"] = pubkey_ref
        if sig_ref:
            certificate_properties["signatureAlgorithmRef"] = sig_ref
        path = cert.get("path") or certificate_properties["subjectName"]
        properties = [
            _prop("serviceUri", service_uri),
            _prop("checklistId", "MDB10-009"),
            _prop("sourcePath", path),
        ]
        for prop_name, key in (("serial", "serial"), ("notBefore", "not_before"), ("notAfter", "not_after")):
            if cert.get(key):
                properties.append(_prop(prop_name, cert[key]))
        bits = _positive_int(cert.get("bits"))
        if bits is not None:
            properties.append(_prop("keyLength", str(bits)))
        if signature:
            properties.append(_prop("signature", signature))
        properties.append(_prop("ca", "true" if cert.get("ca") else "false"))
        if str(cert.get("san") or "").strip():
            properties.append(_prop("san", str(cert.get("san")).strip()))
        builder.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": f"certificate:{path}",
                "name": path,
                "cryptoProperties": {"assetType": "certificate", "certificateProperties": certificate_properties},
                "properties": properties,
            }
        )
    for key in evidence.get("private_keys") or []:
        if "body" in key or "material" in key:
            continue
        alg_ref = ""
        key_type_name = str(key.get("type") or "")
        if key_type_name and key_type_name not in {"metadata", "UNKNOWN"}:
            alg_ref = builder.algorithm(key_type_name, source=key.get("path", ""), checklist_id="MDB10-012")
        material = {
            "type": "private-key",
            "id": key.get("path") or "ssl_key",
            "state": "active",
            "format": "PEM",
        }
        if key.get("bits"):
            material["size"] = int(key["bits"])
        if alg_ref:
            material["algorithmRef"] = alg_ref
        key_properties = [
            _prop("serviceUri", service_uri),
            _prop("checklistId", "MDB10-012"),
            _prop("mode", key.get("mode", "")),
            _prop("owner", key.get("owner", "")),
        ]
        if key.get("usage"):
            key_properties.append(_prop("keyUsage", str(key["usage"])))
        if key_type_name == "UNKNOWN":
            key_properties.append(_prop("keyAlgorithm", "UNKNOWN"))
        builder.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": f"key:{material['id']}",
                "name": material["id"],
                "cryptoProperties": {"assetType": "related-crypto-material", "relatedCryptoMaterialProperties": material},
                "properties": key_properties,
            }
        )
    parsed_ids = evidence.get("file_key_ids") or []
    parsed_paths = {item.get("path") for item in parsed_ids if item.get("path")}
    file_key = evidence.get("file_key") or {}
    if file_key.get("path") and file_key["path"] not in parsed_paths:
        alg_name = _file_key_algorithm_name(evidence) or "AES-CBC"
        alg_ref = builder.algorithm(alg_name, source=file_key["path"], checklist_id="MDB10-036")
        builder.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": f"secret-key:{file_key['path']}",
                "name": file_key["path"],
                "cryptoProperties": {
                    "assetType": "related-crypto-material",
                    "relatedCryptoMaterialProperties": {
                        "type": "secret-key",
                        "id": file_key["path"],
                        "state": "active",
                        "algorithmRef": alg_ref,
                    },
                },
                "properties": [_prop("serviceUri", service_uri), _prop("checklistId", "MDB10-035")],
            }
        )
    scanned_algorithm = _file_key_algorithm_name(evidence)
    for item in parsed_ids:
        path = str(item.get("path") or "")
        key_id = str(item.get("id") or "")
        if not path or not _FILE_KEY_ID.match(key_id):
            continue
        material = {
            "type": "secret-key",
            "id": f"{path}#{key_id}",
            "state": "active",
        }
        if scanned_algorithm:
            material["algorithmRef"] = builder.algorithm(scanned_algorithm, source=path, checklist_id="MDB10-036")
        builder.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": f"secret-key:{path}#{key_id}",
                "name": path,
                "cryptoProperties": {
                    "assetType": "related-crypto-material",
                    "relatedCryptoMaterialProperties": material,
                },
                "properties": [
                    _prop("serviceUri", service_uri),
                    _prop("checklistId", "MDB10-035"),
                    _prop("sourcePath", path),
                    _prop("keyId", key_id),
                ],
            }
        )
    for library in evidence.get("libraries") or []:
        name = library.get("name") if isinstance(library, dict) else str(library)
        if not name:
            continue
        builder.add(
            {
                "type": "library",
                "bom-ref": f"library:{name}",
                "name": name,
                "version": (evidence.get("provider") or {}).get("version", ""),
                "properties": [_prop("serviceUri", service_uri), _prop("checklistId", "MDB10-004")],
            }
        )
    for plugin in (evidence.get("encryption_plugins") or []) + (evidence.get("plugins") or []):
        if not isinstance(plugin, dict):
            continue
        kind = str(plugin.get("type", "")).upper()
        name = plugin.get("name") or ""
        if kind not in {"ENCRYPTION", "AUTHENTICATION"} and name not in {"file_key_management", "ed25519", "gssapi", "auth_pam"}:
            continue
        builder.add(
            {
                "type": "library",
                "bom-ref": f"plugin:{name}",
                "name": name,
                "properties": [
                    _prop("serviceUri", service_uri),
                    _prop("pluginStatus", plugin.get("status", "")),
                    _prop("checklistId", "MDB10-034" if kind == "ENCRYPTION" else "MDB10-022"),
                ],
            }
        )
    for key, check in (
        ("sql_aes", "MDB10-047"),
        ("sql_md5", "MDB10-048"),
        ("sql_sha1", "MDB10-049"),
        ("sql_sha2", "MDB10-050"),
        ("sql_des", "MDB10-051"),
    ):
        locations = _locations(evidence, key)
        if not locations:
            continue
        algorithm = {"sql_aes": "AES-128", "sql_md5": "MD5", "sql_sha1": "SHA-1", "sql_sha2": "SHA-256", "sql_des": "DES"}[key]
        builder.algorithm(algorithm, source="information_schema.ROUTINES", checklist_id=check, locations=locations)
    if evidence.get("sql_random_bytes"):
        builder.add(
            {
                "type": "cryptographic-asset",
                "bom-ref": "algorithm:RANDOM_BYTES",
                "name": "RANDOM_BYTES",
                "cryptoProperties": {
                    "assetType": "algorithm",
                    "algorithmProperties": {"primitive": "drbg", "cryptoFunctions": ["generate"]},
                },
                "properties": [_prop("serviceUri", service_uri), _prop("checklistId", "MDB10-052")],
            }
        )
    app_ref = "application:mariadb-10"
    serial_number = serial or f"urn:uuid:{uuid.uuid4()}"
    binary = evidence.get("binary") or {}
    app_properties = [
        _prop("serviceUri", service_uri),
        _prop("hostname", host),
        _prop("mariadb:pluginVersion", PLUGIN_VERSION),
    ]
    raw_paths = evidence.get("ssl_paths") or {}
    for field, prop_name in (("ssl_cipher", "mariadb:sslCipherExpression"), ("tls_ciphersuites", "mariadb:tlsCiphersuites")):
        if raw_paths.get(field):
            app_properties.append(_prop(prop_name, raw_paths[field]))
    resolution = evidence.get("tls_suite_resolution") or {}
    if resolution:
        app_properties.append(_prop("mariadb:tlsSuiteResolution", json.dumps(resolution, sort_keys=True)))
    host_address = _host_address(host, evidence)
    it_protocol = _it_protocol(evidence)
    it_port = _port(evidence)
    asset_subtype = _asset_subtype(evidence)
    if host_address:
        app_properties.append(_prop("ip", host_address))
    if it_protocol:
        app_properties.append(_prop("itProtocol", it_protocol))
    if it_port:
        app_properties.append(_prop("port", it_port))
    if asset_subtype:
        app_properties.append(_prop("assetSubtype", asset_subtype))
    if binary.get("sha256"):
        app_properties.append(_prop("artifactSha256", binary["sha256"]))
    if binary.get("path"):
        app_properties.append(_prop("artifactPath", binary["path"]))
    document = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "serialNumber": serial_number,
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "tools": [{"name": "mariadb-cbom-ssh", "version": PLUGIN_VERSION}],
            "component": {
                "type": "application",
                "bom-ref": app_ref,
                "name": "MariaDB Server",
                "version": version,
                "properties": app_properties,
            },
        },
        "components": builder.components,
        "dependencies": [{"ref": app_ref, "dependsOn": [component["bom-ref"] for component in builder.components]}],
    }
    for tls_version, suites in suite_groups.items():
        document["dependencies"].append({"ref": f"protocol:{tls_version}", "dependsOn": [f"cipher-suite:{suite}" for suite in suites]})
    return attach_it_asset(document, host)


def it_asset_bom_ref(hostname: str) -> str:
    """Stable CycloneDX ref derived from the host. The same host always gets the same ref."""
    return f"it-asset:{hostname}"


def attach_it_asset(document: dict, hostname: str = "") -> dict:
    """Add the hostname IT asset and link every crypto component to it.

    The IT asset is not an application component. Its name and hostname property
    are the host. Dependencies run both ways: the IT asset depends on each crypto
    ref, and each crypto ref depends on the IT asset.
    """
    metadata = document.get("metadata") if isinstance(document.get("metadata"), dict) else {}
    meta_component = metadata.get("component") if isinstance(metadata.get("component"), dict) else {}
    host = hostname or _component_props(meta_component).get("hostname", "")
    if not host:
        return document
    if meta_component:
        meta_props = meta_component.setdefault("properties", [])
        hostname_prop = next(
            (item for item in meta_props if isinstance(item, dict) and item.get("name") == "hostname"),
            None,
        )
        if hostname_prop is None:
            meta_props.append(_prop("hostname", host))
        elif not hostname_prop.get("value"):
            hostname_prop["value"] = host
        else:
            host = str(hostname_prop["value"])
    ref = it_asset_bom_ref(host)
    components = document.setdefault("components", [])
    if not any(isinstance(item, dict) and item.get("bom-ref") == ref for item in components):
        components.append(
            {
                "type": "device",
                "bom-ref": ref,
                "name": host,
                "properties": [_prop("hostname", host)],
            }
        )
    crypto_refs = [
        str(item.get("bom-ref"))
        for item in components
        if isinstance(item, dict) and item.get("bom-ref") and item.get("bom-ref") != ref
    ]
    dependencies = document.setdefault("dependencies", [])
    by_ref: dict[str, dict] = {}
    for entry in dependencies:
        if isinstance(entry, dict) and entry.get("ref"):
            by_ref[str(entry["ref"])] = entry
    it_entry = by_ref.get(ref)
    if it_entry is None:
        it_entry = {"ref": ref, "dependsOn": []}
        dependencies.append(it_entry)
        by_ref[ref] = it_entry
    it_depends = it_entry.setdefault("dependsOn", [])
    for crypto in crypto_refs:
        if crypto not in it_depends:
            it_depends.append(crypto)
        back = by_ref.get(crypto)
        if back is None:
            back = {"ref": crypto, "dependsOn": []}
            dependencies.append(back)
            by_ref[crypto] = back
        back_depends = back.setdefault("dependsOn", [])
        if ref not in back_depends:
            back_depends.append(ref)
    return document


# target: MariaDB TLS files and SHOW GLOBAL VARIABLES. plane: keys_certs.
# false-positive: a trust store MariaDB does not name is not opened.
_REMOTE = r"""
set +e
export LC_ALL=C
umask 077
SQL="SHOW GLOBAL VARIABLES WHERE Variable_name IN ('version','tls_version','ssl_cipher','tls_ciphersuites','ssl_cert','ssl_key','ssl_ca','ssl_capath','ssl_crl','ssl_crlpath','have_ssl','version_ssl_library','require_secure_transport','port','bind_address','file_key_management_filename','file_key_management_encryption_algorithm','innodb_encrypt_tables','innodb_encrypt_log','innodb_encrypt_temporary_tables','aria_encrypt_tables','encrypt_binlog','wsrep_on','wsrep_provider','wsrep_sst_method')"

run_sql() {
  mysql --batch --skip-column-names --protocol=socket -e "$1" 2>/dev/null && return 0
  mariadb --batch --skip-column-names --protocol=socket -e "$1" 2>/dev/null && return 0
  return 0
}

echo "##BEGIN version##"
mariadbd --version 2>/dev/null || mysqld --version 2>/dev/null || mysql --version 2>/dev/null || true
echo "##END version##"
echo "##BEGIN openssl##"
openssl version 2>/dev/null || true
echo "##END openssl##"
echo "##BEGIN defaults##"
MDB_TLS_DEFAULTS=$(
my_print_defaults mysqld server mariadb 2>/dev/null | sed -E -n '/^--(ssl[-_]cipher|ssl[-_]cert|ssl[-_]key|ssl[-_]ca|ssl[-_]capath|tls[-_]version|tls[-_]ciphersuites|port|file[-_]key[-_]management[-_]filename|file[-_]key[-_]management[-_]encryption[-_]algorithm)(=|$)/p' || true
MDB_SERVER_OPTIONS=$(mariadbd --print-defaults 2>/dev/null || mysqld --print-defaults 2>/dev/null || true)
printf '%s\n' "$MDB_SERVER_OPTIONS" | tr ' ' '\n' | sed -E -n '/^--(ssl[-_]cipher|ssl[-_]cert|ssl[-_]key|ssl[-_]ca|ssl[-_]capath|tls[-_]version|tls[-_]ciphersuites|port|file[-_]key[-_]management[-_]filename|file[-_]key[-_]management[-_]encryption[-_]algorithm)(=|$)/p'
for pattern in /etc/my.cnf /etc/mysql/my.cnf /etc/mysql/mariadb.cnf /etc/my.cnf.d/*.cnf /etc/mysql/mariadb.conf.d/*.cnf /etc/mysql/conf.d/*.cnf; do
  for file in $pattern; do
    [ -f "$file" ] || continue
    sed -E -n 's/^[[:space:]]*(ssl[-_]cipher|ssl[-_]cert|ssl[-_]key|ssl[-_]ca|ssl[-_]capath|tls[-_]version|tls[-_]ciphersuites|file[-_]key[-_]management[-_]filename|file[-_]key[-_]management[-_]encryption[-_]algorithm)[[:space:]]*=[[:space:]]*"?([^"#]+)"?.*/--\1=\2/Ip' "$file"
  done
done
)
printf '%s\n' "$MDB_TLS_DEFAULTS"
echo "##END defaults##"
echo "##BEGIN variables##"
MDB_TLS_VALUES=$(run_sql "$SQL")
printf '%s\n' "$MDB_TLS_VALUES"
echo "##END variables##"
MDB_TLS_STATUS=$(run_sql "SHOW GLOBAL STATUS WHERE Variable_name IN ('Ssl_cipher_list')")
echo "##BEGIN tls_status##"
printf '%s\n' "$MDB_TLS_STATUS"
echo "##END tls_status##"
echo "##BEGIN plugin##"
run_sql "SELECT PLUGIN_NAME, PLUGIN_STATUS, PLUGIN_TYPE, IFNULL(PLUGIN_LIBRARY,'') FROM information_schema.PLUGINS"
echo "##END plugin##"
echo "##BEGIN account##"
run_sql "SELECT plugin, COUNT(*) FROM mysql.user GROUP BY plugin"
run_sql "SELECT JSON_UNQUOTE(JSON_EXTRACT(Priv,'$.plugin')), COUNT(*) FROM mysql.global_priv GROUP BY 1"
echo "##END account##"
echo "##BEGIN routine##"
run_sql "SELECT ROUTINE_SCHEMA, ROUTINE_NAME, CASE WHEN ROUTINE_DEFINITION LIKE '%AES_ENCRYPT%' THEN 'AES_ENCRYPT' WHEN ROUTINE_DEFINITION LIKE '%DES_ENCRYPT%' THEN 'DES_ENCRYPT' WHEN ROUTINE_DEFINITION LIKE '%RANDOM_BYTES%' THEN 'RANDOM_BYTES' WHEN ROUTINE_DEFINITION LIKE '%SHA2(%' THEN 'SHA2' WHEN ROUTINE_DEFINITION LIKE '%SHA1(%' OR ROUTINE_DEFINITION LIKE '%SHA(%' THEN 'SHA1' WHEN ROUTINE_DEFINITION LIKE '%MD5(%' THEN 'MD5' ELSE '' END FROM information_schema.ROUTINES WHERE ROUTINE_DEFINITION LIKE '%AES_ENCRYPT%' OR ROUTINE_DEFINITION LIKE '%DES_ENCRYPT%' OR ROUTINE_DEFINITION LIKE '%RANDOM_BYTES%' OR ROUTINE_DEFINITION LIKE '%SHA2(%' OR ROUTINE_DEFINITION LIKE '%SHA1(%' OR ROUTINE_DEFINITION LIKE '%SHA(%' OR ROUTINE_DEFINITION LIKE '%MD5(%'"
echo "##END routine##"
echo "##BEGIN library##"
pid=$(pgrep -n -x mariadbd || pgrep -n -x mysqld || true)
exe=$(readlink -f "/proc/$pid/exe" 2>/dev/null || command -v mariadbd || command -v mysqld || true)
ldd "$exe" 2>/dev/null | awk 'BEGIN{IGNORECASE=1} /libssl|libcrypto|gnutls|wolfssl|yassl|nss|libgcrypt/ {print}' || true
echo "##END library##"
echo "##BEGIN listener##"
ss -lntup 2>/dev/null || netstat -lntup 2>/dev/null || true
echo "##END listener##"
echo "##BEGIN address##"
hostname -I 2>/dev/null || true
ip -4 -o addr show scope global 2>/dev/null || true
echo "##END address##"

__MDB_TLS_RESOLVER__

emit_cert_pem() {
  local pem="$1"
  local origin="$2"
  local text pub bits sig ca_flag
  text=$(printf '%s\n' "$pem" | openssl x509 -noout -subject -issuer -serial -dates -fingerprint -sha256 -nameopt RFC2253 2>/dev/null) || return 1
  pub=$(printf '%s\n' "$pem" | openssl x509 -noout -text 2>/dev/null | awk '
    /Public Key Algorithm:/ { gsub(/^[[:space:]]+/, ""); print; next }
    /Public-Key:/ { gsub(/^[[:space:]]+/, ""); print; next }
    /Signature Algorithm:/ && !seen { gsub(/^[[:space:]]+/, ""); print; seen=1 }
    /CA:TRUE/ { print "CA:TRUE" }
    /DNS:|IP Address:|email:|URI:/ { gsub(/^[[:space:]]+/, ""); print }
  ')
  bits=$(printf '%s\n' "$pub" | sed -n 's/.*(\([0-9][0-9]*\) bit).*/\1/p' | head -n 1)
  sig=$(printf '%s\n' "$pub" | sed -n 's/^Signature Algorithm:[[:space:]]*//p' | head -n 1)
  sans=$(printf '%s\n' "$pub" | grep -E '^(DNS:|IP Address:|email:|URI:)' | paste -sd ',' -)
  ca_flag=false
  printf '%s\n' "$pub" | grep -q 'CA:TRUE' && ca_flag=true
  echo "##BEGIN cert##"
  echo "path=$origin"
  printf '%s\n' "$text" | sed -n 's/^[Ss]ubject=/subject=/p; s/^[Ii]ssuer=/issuer=/p; s/^[Ss]erial=/serial=/p; s/^notBefore=/notBefore=/p; s/^notAfter=/notAfter=/p; s/^[Ss][Hh][Aa]256 Fingerprint=/fingerprint=/p'
  echo "pubkey=$(printf '%s\n' "$pub" | sed -n 's/Public Key Algorithm:[[:space:]]*//p' | head -n 1)"
  echo "signature=$sig"
  echo "bits=${bits:-0}"
  echo "ca=$ca_flag"
  echo "san=$sans"
  echo "##END cert##"
}

emit_cert_file() {
  local origin="$1"
  local index=0
  local pem=""
  local recording=0
  local line
  [ -f "$origin" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      *"-----BEGIN CERTIFICATE-----"*)
        recording=1
        pem="$line"
        ;;
      *"-----END CERTIFICATE-----"*)
        if [ "$recording" -eq 1 ]; then
          pem="$pem
$line"
          index=$((index + 1))
          if [ "$index" -eq 1 ]; then
            emit_cert_pem "$pem" "$origin" || true
          else
            emit_cert_pem "$pem" "${origin}#${index}" || true
          fi
          recording=0
          pem=""
        fi
        ;;
      *)
        if [ "$recording" -eq 1 ]; then
          pem="$pem
$line"
        fi
        ;;
    esac
  done < "$origin"
}

# target: DER certificate. plane: keys_certs. false-positive: a PEM file named .der is not parsed as DER.
emit_cert_der() {
  local origin="$1"
  local pem
  [ -f "$origin" ] || return 1
  pem=$(openssl x509 -inform DER -in "$origin" -outform PEM 2>/dev/null) || return 1
  case "$pem" in
    *"-----BEGIN CERTIFICATE-----"*) emit_cert_pem "$pem" "$origin" ;;
    *) return 1 ;;
  esac
}

# target: PKCS#7 bundle. plane: keys_certs. false-positive: do not print the PEM; only certificate metadata.
emit_pkcs7() {
  local origin="$1"
  local printed index=0 pem="" recording=0 line
  [ -f "$origin" ] || return 0
  printed=$(openssl pkcs7 -inform PEM -in "$origin" -print_certs 2>/dev/null || openssl pkcs7 -inform DER -in "$origin" -print_certs 2>/dev/null) || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      *"-----BEGIN CERTIFICATE-----"*)
        recording=1
        pem="$line"
        ;;
      *"-----END CERTIFICATE-----"*)
        if [ "$recording" -eq 1 ]; then
          pem="$pem
$line"
          index=$((index + 1))
          if [ "$index" -eq 1 ]; then
            emit_cert_pem "$pem" "$origin" || true
          else
            emit_cert_pem "$pem" "${origin}#${index}" || true
          fi
          recording=0
          pem=""
        fi
        ;;
      *)
        if [ "$recording" -eq 1 ]; then
          pem="$pem
$line"
        fi
        ;;
    esac
  done <<EOF
$printed
EOF
}

# target: Java or PKCS#12 keystore. plane: keys_certs. false-positive: do not try passwords other than empty or changeit, and do not print the store password or a private key.
emit_keystore_closed() {
  local origin="$1"
  echo "##BEGIN key##"
  echo "path=$origin"
  echo "algorithm=UNKNOWN"
  echo "bits=0"
  echo "usage=KEYSTORE"
  echo "##END key##"
}

emit_keystore() {
  local origin="$1"
  local storepass="" ok=0 storetype="" type_arg="" aliases alias exported
  [ -f "$origin" ] || return 0
  if ! command -v keytool >/dev/null 2>&1; then
    emit_keystore_closed "$origin"
    return 0
  fi
  if keytool -list -keystore "$origin" -storepass changeit -noprompt >/dev/null 2>&1; then
    ok=1
    storepass="changeit"
  elif keytool -list -keystore "$origin" -storetype PKCS12 -storepass changeit -noprompt >/dev/null 2>&1; then
    ok=1
    storepass="changeit"
    storetype="PKCS12"
  elif keytool -list -keystore "$origin" -storepass "" -noprompt >/dev/null 2>&1; then
    ok=1
    storepass=""
  fi
  if [ "$ok" -ne 1 ]; then
    emit_keystore_closed "$origin"
    return 0
  fi
  if [ -n "$storetype" ]; then
    type_arg="-storetype PKCS12"
  fi
  aliases=$(keytool -list -v -keystore "$origin" -storepass "$storepass" $type_arg -noprompt 2>/dev/null | awk -F: '/^Alias name:/{gsub(/^[[:space:]]+/,"",$2); gsub(/[[:space:]]+$/,"",$2); print $2}')
  if [ -z "$aliases" ]; then
    emit_keystore_closed "$origin"
    return 0
  fi
  while IFS= read -r alias; do
    [ -n "$alias" ] || continue
    exported=$(keytool -exportcert -rfc -alias "$alias" -keystore "$origin" -storepass "$storepass" $type_arg -noprompt 2>/dev/null) || continue
    case "$exported" in
      *"-----BEGIN CERTIFICATE-----"*) emit_cert_pem "$exported" "${origin}#${alias}" || true ;;
    esac
  done <<EOF
$aliases
EOF
}

emit_file_key_ids() {
  local origin="$1"
  local id
  [ -f "$origin" ] || return 0
  while IFS= read -r id; do
    case "$id" in
      ""|*[!0-9]*) continue ;;
    esac
    echo "##BEGIN filekey##"
    echo "path=$origin"
    echo "id=$id"
    echo "##END filekey##"
  done <<EOF
$(awk '
  {
    line=$0
    sub(/\r$/, "", line)
    sub(/^[[:space:]]+/, "", line)
    sub(/[[:space:]]+$/, "", line)
    if (line ~ /^[0-9]+;[0-9A-Fa-f]+$/) {
      split(line, parts, ";")
      print parts[1]
    }
  }
' "$origin" 2>/dev/null)
EOF
}

emit_key_file() {
  local origin="$1"
  local header alg bits pub
  [ -f "$origin" ] || return 0
  header=$(grep -m1 -E -- '-----BEGIN [A-Z0-9 ]+-----' "$origin" 2>/dev/null | head -n 1 || true)
  case "$header" in
    *"OPENSSH PRIVATE KEY"*)
      # ssh-keygen -l reports size and type. The private-key body is not printed.
      info=$(ssh-keygen -l -f "$origin" 2>/dev/null | head -n 1 || true)
      alg=SSH
      case "$info" in
        *ED25519*) alg=ED25519 ;;
        *ECDSA*) alg=ECDSA ;;
        *RSA*) alg=RSA ;;
        *DSA*) alg=DSA ;;
      esac
      bits=$(printf '%s\n' "$info" | awk '{print $1}')
      case "$bits" in
        ''|*[!0-9]*) bits=0 ;;
      esac
      echo "##BEGIN key##"
      echo "path=$origin"
      echo "algorithm=$alg"
      echo "bits=${bits:-0}"
      echo "owner=$(stat -c '%U' "$origin" 2>/dev/null || true)"
      echo "mode=$(stat -c '%a' "$origin" 2>/dev/null || true)"
      echo "##END key##"
      return 0
      ;;
    *"RSA PRIVATE KEY"*) alg=RSA ;;
    *"EC PRIVATE KEY"*) alg=ECDSA ;;
    *"PRIVATE KEY"*) alg=PKCS8 ;;
    *) return 0 ;;
  esac
  pub=$(openssl pkey -in "$origin" -pubout 2>/dev/null | openssl pkey -pubin -noout -text 2>/dev/null | awk '
    /Public Key Algorithm:/ { gsub(/^[[:space:]]+/, ""); print }
    /Public-Key:/ { gsub(/^[[:space:]]+/, ""); print }
    /ASN1 OID:/ { gsub(/^[[:space:]]+/, ""); print }
    /Modulus:/ { print "KIND:RSA" }
  ')
  case "$pub" in
    *priv:*|*"PRIVATE KEY"*) pub="" ;;
  esac
  bits=$(printf '%s\n' "$pub" | sed -n 's/.*(\([0-9][0-9]*\) bit).*/\1/p' | head -n 1)
  case "$pub" in
    *id-ecPublicKey*|*prime256v1*) alg=ECDSA ;;
    *rsaEncryption*|*KIND:RSA*) alg=RSA ;;
    *ED25519*|*ed25519*) alg=Ed25519 ;;
  esac
  echo "##BEGIN key##"
  echo "path=$origin"
  echo "algorithm=$alg"
  echo "bits=${bits:-0}"
  echo "owner=$(stat -c '%U' "$origin" 2>/dev/null || true)"
  echo "mode=$(stat -c '%a' "$origin" 2>/dev/null || true)"
  echo "##END key##"
}

# target: one certificate or key file. plane: keys_certs. false-positive: a .txt file is a file-key id scan, not a certificate.
consider_asset() {
  local one="$1"
  [ -f "$one" ] || return 0
  case "$one" in
    *.txt|*.TXT) emit_file_key_ids "$one" ;;
    *.key|*.KEY)
      emit_key_file "$one"
      emit_file_key_ids "$one"
      ;;
    *.p7b|*.p7c|*.P7B|*.P7C) emit_pkcs7 "$one" ;;
    *.jks|*.keystore|*.truststore|*.jceks|*.p12|*.pfx|*.JKS|*.P12|*.PFX|*cacerts|*jssecacerts)
      emit_keystore "$one"
      ;;
    *.der|*.DER) emit_cert_der "$one" || true ;;
    *)
      if grep -q -m1 -- '-----BEGIN CERTIFICATE-----' "$one" 2>/dev/null; then
        emit_cert_file "$one"
      else
        emit_cert_der "$one" || true
      fi
      if grep -q -m1 -E -- '-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----' "$one" 2>/dev/null; then
        emit_key_file "$one"
      fi
      emit_file_key_ids "$one"
      ;;
  esac
}

echo "##BEGIN assets##"
DATADIR=$(my_print_defaults mysqld 2>/dev/null | sed -n 's/^--datadir=//p' | tail -n 1)
PID=$(pgrep -n -x mariadbd || pgrep -n -x mysqld || true)
PROC_DIR=""
if [ -n "$PID" ]; then
  PROC_DIR=$(readlink -f "/proc/$PID/cwd" 2>/dev/null || true)
  cmdline_dir=$(tr '\0' '\n' < "/proc/$PID/cmdline" 2>/dev/null | sed -n 's/^--datadir=//p' | tail -n 1)
  if [ -n "$cmdline_dir" ]; then
    DATADIR="$cmdline_dir"
  elif [ -z "$DATADIR" ] && [ -n "$PROC_DIR" ]; then
    DATADIR="$PROC_DIR"
  fi
fi
DATADIR=${DATADIR:-/var/lib/mysql}
SEEN=" "
open_named() {
  local key="$1"
  local val="$2"
  [ -n "$key" ] || return 0
  [ -n "$val" ] || return 0
  case "$val" in
    /*) ;;
    *) val="${DATADIR%/}/$val" ;;
  esac
  case " $SEEN " in
    *" $val "*) return 0 ;;
  esac
  SEEN="$SEEN $val"
  case "$key" in
    ssl_cert|ssl_ca) consider_asset "$val" ;;
    ssl_capath)
      if [ -d "$val" ]; then
        find "$val" -maxdepth 1 \( -type f -o -type l \) \( -iname '*.crt' -o -iname '*.pem' -o -iname '*.cer' -o -iname '*.der' -o -iname '*.p7b' -o -iname '*.p7c' \) -size -2M 2>/dev/null | while IFS= read -r one; do
          consider_asset "$one"
        done
      fi
      ;;
    ssl_key) emit_key_file "$val" ;;
  esac
}
while IFS=$(printf '\t') read -r name value; do
  key=$(printf '%s' "$name" | tr 'A-Z-' 'a-z_')
  val=$(printf '%s' "$value" | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//; s/^"//; s/"$//; s/[[:space:]]+$//')
  open_named "$key" "$val"
done <<EOF
$(run_sql "$SQL" | awk -F '\t' '$1=="ssl_cert" || $1=="ssl_key" || $1=="ssl_ca" || $1=="ssl_capath" {print $1 "\t" $2}')
$(for pattern in /etc/my.cnf /etc/mysql/my.cnf /etc/mysql/mariadb.cnf /etc/my.cnf.d/*.cnf /etc/mysql/mariadb.conf.d/*.cnf /etc/mysql/conf.d/*.cnf; do
  for file in $pattern; do
    [ -f "$file" ] || continue
    sed -E -n 's/^[[:space:]]*(ssl[-_](cert|key|capath|ca))[[:space:]]*=[[:space:]]*"?([^"#]+)"?.*/\1\t\3/Ip' "$file"
  done
done)
$({ my_print_defaults mysqld 2>/dev/null; mariadbd --print-defaults 2>/dev/null; mysqld --print-defaults 2>/dev/null; } | tr ' ' '\n' | sed -n 's/^--//p' | awk -F= 'BEGIN{OFS="\t"} $1=="ssl-cert" || $1=="ssl_cert" || $1=="ssl-key" || $1=="ssl_key" || $1=="ssl-ca" || $1=="ssl_ca" || $1=="ssl-capath" || $1=="ssl_capath" {print $1, $2}')
EOF
remember_file_key() {
  local val="$1"
  [ -n "$val" ] || return 0
  val=$(printf '%s' "$val" | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//; s/^"//; s/"$//')
  [ -n "$val" ] || return 0
  case "$val" in
    /*) ;;
    *) val="${DATADIR%/}/$val" ;;
  esac
  case " $SEEN " in
    *" $val "*) return 0 ;;
  esac
  SEEN="$SEEN $val"
  emit_file_key_ids "$val"
}
file_key_named=$(run_sql "$SQL" | awk -F '\t' '$1=="file_key_management_filename" { print $2; exit }')
remember_file_key "$file_key_named"
file_key_named=$({ my_print_defaults mysqld 2>/dev/null; mariadbd --print-defaults 2>/dev/null; mysqld --print-defaults 2>/dev/null; } | tr ' ' '\n' | sed -n 's/^--file-key-management-filename=//p' | tail -n 1)
remember_file_key "$file_key_named"
for dir in /etc/my.cnf.d /etc/mysql /var/lib/mysql /var/lib/mariadb "$DATADIR" "$PROC_DIR"; do
  [ -d "$dir" ] || continue
  find "$dir" -maxdepth 2 \( -type f -o -type l \) \
    \( -iname '*.crt' -o -iname '*.pem' -o -iname '*.cert' -o -iname '*.cer' -o -iname '*.key' -o -iname '*.txt' \
       -o -iname '*.der' -o -iname '*.p7b' -o -iname '*.p7c' -o -iname '*.p12' -o -iname '*.pfx' \
       -o -iname '*.jks' -o -iname '*.keystore' -o -iname '*.truststore' -o -iname '*.jceks' \
       -o -iname 'cacerts' -o -iname 'jssecacerts' \) \
    -size -2M 2>/dev/null | while IFS= read -r one; do
    [ -n "$one" ] || continue
    case " $SEEN " in
      *" $one "*) continue ;;
    esac
    SEEN="$SEEN $one"
    consider_asset "$one"
  done
done
echo "##END assets##"
echo "##BEGIN trace##"
echo "datadir=$DATADIR"
echo "procdir=$PROC_DIR"
echo "##END trace##"
"""

_SECTION_NAMES = (
    "version",
    "openssl",
    "tls_status",
    "tls_cipher_result",
    "defaults",
    "variables",
    "plugin",
    "account",
    "routine",
    "library",
    "listener",
    "address",
    "trace",
    "cert",
    "key",
    "filekey",
)


def _blocks(text: str) -> dict[str, list[str]]:
    """Read every marked section. Certificate blocks sit inside the asset scan, so each name is matched on its own."""
    found: dict[str, list[str]] = defaultdict(list)
    for name in _SECTION_NAMES:
        for body in re.findall(rf"##BEGIN {name}##\n(.*?)##END {name}##", text, re.S):
            found[name].append(body.strip("\n"))
    return found


_SECRET = re.compile(r"(password|passwd|secret|token|private key|-----BEGIN )", re.I)


def render_remote(mysql_password: str = "") -> str:
    """Return the remote script. A MySQL password is passed only inside stdin."""
    prefix = ""
    if mysql_password:
        prefix = "export MYSQL_PWD=" + shlex.quote(mysql_password) + "\n"
    return prefix + _REMOTE.replace("__MDB_TLS_RESOLVER__", tls_inventory.render_remote_resolver())


def remote_command(use_sudo: bool, sudo_password: str) -> str:
    """Match MariaDB login: sudo -S when a sudo password is set, else sudo -n."""
    if use_sudo and sudo_password:
        return "sudo -S -p '' -k -- bash -s"
    if use_sudo:
        return "sudo -n bash -s"
    return "bash -s"


def _redact(text: str, secrets: list[str]) -> str:
    cleaned = text
    for secret in secrets:
        if secret:
            cleaned = cleaned.replace(secret, "<redacted>")
    return cleaned


def _pairs(block: str) -> dict[str, str]:
    found = {}
    for line in block.splitlines():
        if "\t" not in line:
            continue
        name, value = line.split("\t", 1)
        name = name.strip()
        if not name or _SECRET.search(name):
            continue
        found[name] = value.strip()
    return found


def _fields(block: str) -> dict[str, str]:
    found = {}
    for line in block.splitlines():
        if "=" not in line:
            continue
        name, value = line.split("=", 1)
        found[name.strip()] = value.strip()
    return found


def _pubkey_name(value: str) -> str:
    text = value.lower()
    if "rsa" in text:
        return "RSA"
    if "ec" in text or "prime256" in text or "id-ec" in text:
        return "ECDSA"
    if "ed25519" in text:
        return "Ed25519"
    if "dsa" in text:
        return "DSA"
    return value


def _merge_defaults(variables: dict[str, str], block: str) -> None:
    """Fill TLS paths and cipher settings from the effective MariaDB options when SQL did not."""
    aliases = {
        "ssl_cert": "ssl_cert",
        "ssl_key": "ssl_key",
        "ssl_ca": "ssl_ca",
        "ssl_capath": "ssl_capath",
        "ssl_cipher": "ssl_cipher",
        "tls_version": "tls_version",
        "tls_ciphersuites": "tls_ciphersuites",
        "port": "port",
        "file_key_management_filename": "file_key_management_filename",
        "file_key_management_encryption_algorithm": "file_key_management_encryption_algorithm",
    }
    for line in block.splitlines():
        matches = list(re.finditer(r"--([A-Za-z0-9_-]+)=(\S+)", line))
        pairs = [(match.group(1), match.group(2)) for match in matches]
        if not pairs and "=" in line:
            name, value = line.split("=", 1)
            pairs = [(name.strip().lstrip("-"), value.strip())]
        for name, value in pairs:
            dest = aliases.get(name.strip().lower().replace("-", "_"))
            value = value.strip().strip("\"'")
            if dest and value and not variables.get(dest):
                variables[dest] = value


def _file_key_ids(blocks: dict[str, list[str]]) -> list[dict[str, str]]:
    """Keep the path and numeric key id. The hex half of a file-key line is never stored."""
    found = []
    seen: set[tuple[str, str]] = set()
    for block in blocks.get("filekey", []):
        item = _fields(block)
        path = str(item.get("path") or "").strip()
        key_id = str(item.get("id") or "").strip()
        if not path or not _FILE_KEY_ID.match(key_id):
            continue
        if _FILE_KEY_HEX.search(path) or _FILE_KEY_HEX.search(key_id):
            continue
        pair = (path, key_id)
        if pair in seen:
            continue
        seen.add(pair)
        found.append({"path": path, "id": key_id})
    return found


def evidence_from_transcript(text: str, hostname: str) -> dict:
    """Turn the remote transcript into the evidence the MariaDB CBOM builder uses."""
    blocks = _blocks(text)
    variables = _pairs(blocks.get("variables", [""])[0] if blocks.get("variables") else "")
    _merge_defaults(variables, blocks.get("defaults", [""])[0] if blocks.get("defaults") else "")
    openssl_text = (blocks.get("openssl", [""])[0] if blocks.get("openssl") else "").strip()
    if openssl_text and not variables.get("version_ssl_library"):
        variables["version_ssl_library"] = openssl_text.splitlines()[0].strip()
    certificates = []
    for block in blocks.get("cert", []):
        item = _fields(block)
        path = item.get("path", "")
        if not path:
            continue
        certificates.append(
            {
                "path": path,
                "subject": item.get("subject", ""),
                "issuer": item.get("issuer", ""),
                "fingerprint": item.get("fingerprint", ""),
                "pubkey_algorithm": _pubkey_name(item.get("pubkey", "")),
                "signature_algorithm": item.get("signature", ""),
                "serial": item.get("serial", ""),
                "not_before": item.get("notBefore", ""),
                "not_after": item.get("notAfter", ""),
                "bits": item.get("bits", ""),
                "ca": str(item.get("ca", "")).strip().lower() == "true",
                "san": item.get("san", ""),
            }
        )
    keys = []
    for block in blocks.get("key", []):
        item = _fields(block)
        path = item.get("path", "")
        if not path:
            continue
        algorithm = item.get("algorithm") or "metadata"
        usage = str(item.get("usage") or "").strip()
        if algorithm == "UNKNOWN" and usage != "KEYSTORE":
            algorithm = "metadata"
        try:
            bits = int(item.get("bits") or 0)
        except ValueError:
            bits = 0
        keys.append(
            {
                "path": path,
                "type": algorithm,
                "bits": bits,
                "owner": item.get("owner", ""),
                "mode": item.get("mode", ""),
                "usage": usage,
            }
        )
    routines = blocks.get("routine", [""])[0] if blocks.get("routine") else ""

    def hits(label: str) -> list[dict]:
        rows = []
        for line in routines.splitlines():
            parts = line.split("\t")
            if len(parts) >= 3 and parts[2].strip() == label:
                rows.append({"location": f"{parts[0]}.{parts[1]}", "function": label})
        return rows

    plugins = []
    encryption = []
    plugin_text = blocks.get("plugin", [""])[0] if blocks.get("plugin") else ""
    for line in plugin_text.splitlines():
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        item = {
            "name": parts[0],
            "status": parts[1],
            "type": parts[2],
            "library": parts[3] if len(parts) > 3 else "",
        }
        plugins.append(item)
        if parts[2].upper() == "ENCRYPTION" or "key_management" in parts[0].lower():
            encryption.append(item)
    accounts: dict[str, int] = {}
    account_text = blocks.get("account", [""])[0] if blocks.get("account") else ""
    for line in account_text.splitlines():
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().isdigit():
            accounts[parts[0].strip().lower()] = int(parts[1].strip())
    libraries = []
    library_text = blocks.get("library", [""])[0] if blocks.get("library") else ""
    for line in library_text.splitlines():
        if line.strip():
            libraries.append({"name": line.split()[0], "path": line.strip()})
    listener_text = blocks.get("listener", [""])[0] if blocks.get("listener") else ""
    version = variables.get("version") or (blocks.get("version", [""])[0] if blocks.get("version") else "").strip()
    cipher = variables.get("ssl_cipher", "")
    tls13 = variables.get("tls_ciphersuites", "")
    evidence = {
        "hostname": hostname,
        "server_port": variables.get("port", ""),
        "bind_address": variables.get("bind_address", ""),
        "addresses": _host_addresses(blocks.get("address", [""])[0] if blocks.get("address") else ""),
        "version": version,
        "binary": {},
        "libraries": libraries,
        "provider": {"version": variables.get("version_ssl_library", "")},
        "listeners": [
            line
            for line in listener_text.splitlines()
            if variables.get("port", "3306") in line or "mariadb" in line.lower() or "mysql" in line.lower()
        ],
        "certificates": certificates,
        "private_keys": keys,
        "tls_versions": [item.strip() for item in variables.get("tls_version", "").split(",") if item.strip()],
        "tls_suite_resolution": tls_inventory.parse_expansions(blocks.get("tls_cipher_result", [])),
        "tls12_suites": _cipher_entries(cipher),
        "tls13_suites": [item for item in tls13.split(":") if item] + [item for item in cipher.split(":") if item.startswith("TLS_")],
        "groups": [item.strip() for item in variables.get("tls_group", "").split(",") if item.strip()],
        "plugins": plugins,
        "encryption_plugins": encryption,
        "have_ssl": variables.get("have_ssl", ""),
        "version_ssl_library": variables.get("version_ssl_library", ""),
        "file_key": {"path": variables.get("file_key_management_filename", "")},
        "file_key_algorithm": variables.get("file_key_management_encryption_algorithm", ""),
        "file_key_ids": _file_key_ids(blocks),
        "innodb_encrypt_tables": variables.get("innodb_encrypt_tables", ""),
        "innodb_encrypt_log": variables.get("innodb_encrypt_log", ""),
        "innodb_encrypt_temporary_tables": variables.get("innodb_encrypt_temporary_tables", ""),
        "aria_encrypt_tables": variables.get("aria_encrypt_tables", ""),
        "encrypt_binlog": variables.get("encrypt_binlog", ""),
        "sql_aes": hits("AES_ENCRYPT"),
        "sql_md5": hits("MD5"),
        "sql_sha1": hits("SHA1"),
        "sql_sha2": hits("SHA2"),
        "sql_des": hits("DES_ENCRYPT"),
        "sql_random_bytes": hits("RANDOM_BYTES"),
        "native_accounts": accounts.get("mysql_native_password"),
        "ed25519_accounts": accounts.get("ed25519"),
        "live_ssh": True,
        "ssl_paths": {
            "ssl_cert": variables.get("ssl_cert", ""),
            "ssl_key": variables.get("ssl_key", ""),
            "ssl_ca": variables.get("ssl_ca", ""),
            "tls_version": variables.get("tls_version", ""),
            "ssl_cipher": variables.get("ssl_cipher", ""),
            "tls_ciphersuites": variables.get("tls_ciphersuites", ""),
        },
        "trace": _fields(blocks.get("trace", [""])[0] if blocks.get("trace") else ""),
    }
    if not evidence["file_key"]["path"]:
        evidence.pop("file_key")
    if not evidence["file_key_algorithm"]:
        evidence.pop("file_key_algorithm", None)
    if evidence["native_accounts"] is None:
        evidence.pop("native_accounts")
    if evidence["ed25519_accounts"] is None:
        evidence.pop("ed25519_accounts")
    return evidence


def _append(document: dict, component: dict) -> None:
    if any(item.get("bom-ref") == component["bom-ref"] for item in document["components"]):
        return
    document["components"].append(component)
    dependencies = document.get("dependencies") or []
    if dependencies:
        dependencies[0].setdefault("dependsOn", []).append(component["bom-ref"])


def _code_component(service_uri: str, location: str, function_name: str, algorithm: str, language: str, purpose: str) -> dict:
    return {
        "type": "cryptographic-asset",
        "bom-ref": f"code:{location}:{function_name}",
        "name": location,
        "cryptoProperties": {
            "assetType": "algorithm",
            "algorithmProperties": {
                "primitive": "unknown",
                "parameterSetIdentifier": algorithm,
                "cryptoFunctions": ["other"],
            },
        },
        "properties": [
            {"name": "serviceUri", "value": service_uri},
            {"name": "assetKind", "value": "code-asset"},
            {"name": "functionName", "value": function_name},
            {"name": "algorithm", "value": algorithm},
            {"name": "language", "value": language},
            {"name": "purpose", "value": purpose},
        ],
    }


def build_upload_cbom(evidence: dict, hostname: str) -> dict:
    """Return the CycloneDX document GCM imports as a CBOM report."""
    rows = rows_from_evidence(evidence, fixture=hostname or "live")
    for name, field in (
        ("AES-256", "innodb_encrypt_tables"),
        ("AES-256", "innodb_encrypt_log"),
        ("AES-256", "innodb_encrypt_temporary_tables"),
        ("AES-256", "aria_encrypt_tables"),
        ("AES-256", "encrypt_binlog"),
    ):
        if str(evidence.get(field, "")).upper() in {"ON", "FORCE"}:
            rows.append(
                {
                    "fixture": hostname,
                    "algorithm": name,
                    "risk": "QUANTUM_RESISTANT",
                    "active": True,
                    "plane": "at_rest",
                    "gcm_category": "cipher_suite",
                    "checklist_id": "MDB10-039",
                    "source_path": field,
                }
            )
    document = build_cbom(evidence, rows, hostname=hostname)
    service_uri = f"mysql://{hostname}:3306"
    for component in document.get("components", []):
        if not str(component.get("bom-ref", "")).startswith("certificate:"):
            continue
        path = component["bom-ref"].split(":", 1)[1]
        match = next((item for item in evidence.get("certificates") or [] if item.get("path") == path), None)
        if not match:
            continue
        properties = component.setdefault("properties", [])
        present = {item.get("name") for item in properties if isinstance(item, dict)}
        for prop_name, key in (("serial", "serial"), ("notBefore", "not_before"), ("notAfter", "not_after")):
            if prop_name not in present and match.get(key):
                properties.append({"name": prop_name, "value": str(match[key])})
    mapping = (
        ("sql_aes", "AES_ENCRYPT", "AES-128", "SQL"),
        ("sql_md5", "MD5", "MD5", "SQL"),
        ("sql_sha1", "SHA1", "SHA-1", "SQL"),
        ("sql_sha2", "SHA2", "SHA-256", "SQL"),
        ("sql_des", "DES_ENCRYPT", "DES", "SQL"),
        ("sql_random_bytes", "RANDOM_BYTES", "RANDOM_BYTES", "SQL"),
    )
    for key, function_name, algorithm, language in mapping:
        for hit in evidence.get(key) or []:
            _append(
                document,
                _code_component(
                    service_uri,
                    str(hit.get("location") or function_name),
                    function_name,
                    algorithm,
                    language,
                    "MariaDB routine cryptographic call",
                ),
            )
    for plugin in evidence.get("encryption_plugins") or []:
        location = str(plugin.get("library") or plugin.get("name") or "")
        if not location:
            continue
        _append(
            document,
            _code_component(
                service_uri,
                location,
                str(plugin.get("name") or "plugin"),
                str(plugin.get("type") or "ENCRYPTION"),
                "plugin",
                f"status={plugin.get('status', '')}",
            ),
        )
    encoded = json.dumps(document)
    _reject_key_material(encoded)
    return attach_it_asset(document, hostname)


def _component_props(component: dict) -> dict[str, str]:
    found = {}
    for prop in component.get("properties") or []:
        if isinstance(prop, dict) and prop.get("name"):
            found[str(prop["name"])] = str(prop.get("value") or "")
    return found


def _present(values: dict) -> dict:
    """Keep only values the CBOM actually carried."""
    row = {}
    for key, value in values.items():
        if value is None:
            continue
        if isinstance(value, str) and not value.strip():
            continue
        row[key] = value
    return row


def _positive_int(value) -> int | None:
    if isinstance(value, bool) or value is None or value == "":
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    text = str(value).strip()
    if text.isdigit():
        number = int(text)
        return number if number > 0 else None
    return None


def _ref_name(value: str) -> str:
    text = str(value or "").strip()
    if ":" in text:
        return text.split(":")[-1]
    return text


def _gcm_key_type(material_type: str) -> str:
    kind = str(material_type or "").strip().lower()
    if kind in {"private-key", "public-key"}:
        return "ASYMMETRIC"
    if kind in {"secret-key", "symmetric-key"}:
        return "SYMMETRIC"
    return ""


_UNSPECIFIED_ADDRESSES = {"", "*", "0.0.0.0", "::", "::0", "localhost", "127.0.0.1", "::1"}


def _is_host_address(value: str) -> bool:
    text = str(value or "").strip()
    if text.lower() in _UNSPECIFIED_ADDRESSES:
        return False
    try:
        ipaddress.ip_address(text)
    except ValueError:
        return False
    return True


def _host_addresses(block: str) -> list[str]:
    """Addresses printed by hostname -I or ip. Broadcast and unspecified addresses are not kept."""
    found: list[str] = []
    for line in str(block or "").splitlines():
        inet = re.search(r"\binet6?\s+(\S+)", line)
        tokens = [inet.group(1)] if inet else line.split()
        for token in tokens:
            address = token.split("/")[0]
            if _is_host_address(address) and address not in found:
                found.append(address)
    return found


def _host_address(hostname: str, evidence: dict) -> str:
    """SSH target when it is an address, otherwise an address the host actually printed."""
    if _is_host_address(hostname):
        return str(hostname).strip()
    candidates: list[str] = []
    bind = str(evidence.get("bind_address") or "").strip()
    if _is_host_address(bind):
        candidates.append(bind)
    for address in evidence.get("addresses") or []:
        text = str(address).strip()
        if _is_host_address(text) and text not in candidates:
            candidates.append(text)
    ipv4 = [address for address in candidates if "." in address]
    if ipv4:
        return ipv4[0]
    return candidates[0] if candidates else ""


def _it_protocol(evidence: dict) -> str:
    """TLS when MariaDB reports TLS. Otherwise only a protocol token the listener line shows."""
    have = str(evidence.get("have_ssl") or "").strip().upper()
    versions = [str(item).strip() for item in (evidence.get("tls_versions") or []) if str(item).strip()]
    if have in {"YES", "ON", "TRUE", "1"}:
        return "TLS"
    if versions and have not in {"NO", "OFF", "FALSE", "0", "DISABLED"}:
        return "TLS"
    saw_tcp = False
    saw_udp = False
    for listener in evidence.get("listeners") or []:
        text = str(listener).strip().lower()
        if re.search(r"(^|\s)tcp6?(\s|$)", text):
            saw_tcp = True
        elif re.search(r"(^|\s)udp6?(\s|$)", text):
            saw_udp = True
    if saw_tcp:
        return "TCP"
    if saw_udp:
        return "UDP"
    return ""


def _asset_subtype(evidence: dict) -> str:
    version = str(evidence.get("version") or "")
    if "mariadb" in version.lower():
        return "MariaDB"
    return ""


def _it_asset_uri(hostname: str, service_uri: str) -> str:
    """IT-asset unique identifier: hostname:port, with no scheme.

    IBM's linking page identifies an IT asset by its URI. The association
    example is ``myserver.mydomain.com:8443``. The portal row for this host
    on port 3306 uses that same host:port form. A bare hostname leaves the
    asset port empty.
    """
    tail = service_uri.split("://", 1)[-1] if service_uri else ""
    port = ""
    if hostname and tail.startswith(hostname + ":"):
        port = tail[len(hostname) + 1 :].split("/")[0]
    elif tail.count(":") == 1:
        _host, maybe_port = tail.split(":", 1)
        maybe_port = maybe_port.split("/")[0]
        if maybe_port.isdigit():
            port = maybe_port
    if hostname and port.isdigit():
        return f"{hostname}:{port}"
    return hostname


def discovery_from_cbom(document: dict) -> list[dict]:
    """Turn the CycloneDX CBOM into the flat array transform_discover.json reads.

    --output stays the CycloneDX document. This array is only for --discovery-output.
    Field names match the 0.0.2 xpaths: hostname, uri, service_uri, key_type,
    certificate_serial_number, cipher_suite, and code_location.
    ``uri`` on the server row and on every crypto row is the same IT-asset URI.
    """
    metadata = document.get("metadata") or {}
    component = metadata.get("component") or {}
    meta_props = _component_props(component)
    hostname = meta_props.get("hostname", "")
    meta_service = meta_props.get("serviceUri", "")
    asset_uri = _it_asset_uri(hostname, meta_service)
    rows: list[dict] = []
    legacy_config = []
    for field, prop_name in (("ssl_cipher", "mariadb:sslCipherExpression"), ("tls_ciphersuites", "mariadb:tlsCiphersuites")):
        if meta_props.get(prop_name):
            legacy_config.append({"category": "tls-configuration", "hostname": hostname, "uri": asset_uri,
                                  "source": field, "configured_value": meta_props[prop_name]})

    # Preserve explicit usage references as evidence on algorithm rows.
    # Classification follows asset type, never whether a certificate uses it.
    algorithm_users: dict[str, set[str]] = defaultdict(set)
    for item in document.get("components") or []:
        if not isinstance(item, dict):
            continue
        owner_ref = str(item.get("bom-ref") or "").strip()
        crypto_props = item.get("cryptoProperties") or {}
        cert_props = crypto_props.get("certificateProperties") or {}
        for field in ("subjectPublicKeyRef", "signatureAlgorithmRef"):
            ref = str(cert_props.get(field) or "").strip()
            if ref and owner_ref:
                algorithm_users[ref].add(owner_ref)
        material = crypto_props.get("relatedCryptoMaterialProperties") or {}
        material_ref = str(material.get("algorithmRef") or "").strip()
        if material_ref and owner_ref:
            algorithm_users[material_ref].add(owner_ref)
    for dependency in document.get("dependencies") or []:
        if not isinstance(dependency, dict):
            continue
        owner_ref = str(dependency.get("ref") or "").strip()
        for ref in dependency.get("dependsOn") or []:
            if ref and owner_ref:
                algorithm_users[str(ref)].add(owner_ref)
    if hostname:
        it_row = {
            "category": "it-asset",
            "hostname": hostname,
            "uri": asset_uri,
            "asset_type": "Database",
        }
        if meta_props.get("ip"):
            it_row["ip"] = meta_props["ip"]
        if meta_props.get("itProtocol"):
            it_row["protocol"] = meta_props["itProtocol"]
        if meta_props.get("port"):
            it_row["port"] = meta_props["port"]
        if meta_props.get("assetSubtype"):
            it_row["asset_subtype"] = meta_props["assetSubtype"]
        rows.append(it_row)
    for item in document.get("components") or []:
        if not isinstance(item, dict):
            continue
        ref = str(item.get("bom-ref") or "")
        kind = ref.split(":", 1)[0]
        name = str(item.get("name") or "")
        props = _component_props(item)
        crypto = item.get("cryptoProperties") or {}
        asset_kind = props.get("assetKind", "")
        service = props.get("serviceUri") or meta_service
        shared = _present(
            {
                "hostname": hostname,
                "uri": asset_uri or _it_asset_uri(hostname, service),
                "service_uri": asset_uri or _it_asset_uri(hostname, service),
            }
        )
        if kind == "protocol" or asset_kind == "protocol":
            protocol_props = crypto.get("protocolProperties") or {}
            version = str(protocol_props.get("version") or name)
            suites = tls_inventory.canonical_names(entry.get("name", "") for entry in protocol_props.get("cipherSuites", []) if isinstance(entry, dict))
            rows.append(
                _present(
                    {
                        **shared,
                        "category": "protocol",
                        "cipher_type": asset_kind or "protocol",
                        "protocol": protocol_props.get("type") or "",
                        "tls_version": version,
                        "ciphers_available": suites,
                        "ciphers_available_json": json.dumps(suites),
                        "source": props.get("sourcePath") or "",
                        "checklist_id": props.get("checklistId") or "",
                    }
                )
            )
        elif kind == "cipher-suite" or asset_kind == "cipher-suite":
            protocol_props = crypto.get("protocolProperties") or {}
            iana_name = tls_inventory.canonical_name(name)
            if not iana_name:
                legacy_config.append(_present({**shared, "category": "tls-configuration", "source": props.get("sourcePath") or "ssl_cipher",
                                               "configured_value": name, "resolution_status": "unresolved_legacy_value"}))
                continue
            rows.append(
                _present(
                    {
                        **shared,
                        "category": "cipher",
                        "cipher_suite": iana_name,
                        "cipher_type": asset_kind or "cipher-suite",
                        "protocol": protocol_props.get("type") or "",
                        "source": props.get("sourcePath") or "",
                        "checklist_id": props.get("checklistId") or "",
                    }
                )
            )
        elif kind == "algorithm" or (
            crypto.get("assetType") == "algorithm" and asset_kind != "code-asset"
        ):
            # An algorithm is not a TLS cipher suite. Retain its evidence and
            # references in a distinct row; the existing ciphers transformer
            # selects category='cipher' and therefore excludes these records.
            # A GCM mapping for standalone algorithms needs a confirmed schema.
            algorithm_props = crypto.get("algorithmProperties") or {}
            primitive = str(algorithm_props.get("primitive") or "")
            functions = [str(function) for function in (algorithm_props.get("cryptoFunctions") or [])]
            row = {
                **shared,
                "category": "algorithm",
                "name": name,
                "cbom_bom_ref": ref,
                "primitive": primitive or "unknown",
                "crypto_functions": functions,
                "referenced_by": sorted(algorithm_users.get(ref, set())),
                "parameter_set_identifier": algorithm_props.get("parameterSetIdentifier") or "",
                "curve": algorithm_props.get("curve") or "",
                "source": props.get("sourcePath") or "",
                "checklist_id": props.get("checklistId") or "",
                "mode": algorithm_props.get("mode") or "",
            }
            if primitive == "hash" or "digest" in functions:
                row["hashing_algorithm"] = name
            if primitive in {"pke", "block-cipher", "stream-cipher", "ae"} or "encrypt" in functions:
                row["encryption_algorithm"] = name
            rows.append(_present(row))
        elif kind == "certificate" or crypto.get("assetType") == "certificate":
            cert = crypto.get("certificateProperties") or {}
            certificate_row = _present(
                {
                    **shared,
                    "category": "certificate",
                    "file_path": props.get("sourcePath") or name,
                    "subject": cert.get("subjectName") or "",
                    "issuer": cert.get("issuerName") or "",
                    "not_before": props.get("notBefore") or "",
                    "not_after": props.get("notAfter") or "",
                    "certificate_serial_number": props.get("serial") or "",
                    "key_algorithm": _ref_name(str(cert.get("subjectPublicKeyRef") or "")),
                    "hashing_algorithm": props.get("signature") or "",
                    "checklist_id": props.get("checklistId") or "",
                }
            )
            certificate_bits = _positive_int(props.get("keyLength"))
            if certificate_bits is not None:
                certificate_row["key_length"] = certificate_bits
            certificate_row["is_ca_certificate"] = str(props.get("ca") or "").strip().lower() == "true"
            certificate_row["san_raw"] = props.get("san") or ""
            rows.append(certificate_row)
        elif kind == "key" or crypto.get("assetType") == "related-crypto-material":
            material = crypto.get("relatedCryptoMaterialProperties") or {}
            length = _positive_int(material.get("size"))
            state = str(material.get("state") or "")
            if state == "active":
                state = "ACTIVE"
            key_id = props.get("keyId") or ""
            source_path = props.get("sourcePath") or ""
            if key_id and source_path:
                file_path = source_path
                identity = key_id
            else:
                file_path = material.get("id") or name
                identity = material.get("id") or ""
                key_id = ""
            row = {
                **shared,
                "category": "key",
                "file_path": file_path,
                "key_id": key_id,
                "key_type": _gcm_key_type(str(material.get("type") or "")),
                "key_algorithm": _ref_name(str(material.get("algorithmRef") or "")) or props.get("keyAlgorithm") or "",
                "key_state": state,
                "public_hash_key_value": identity,
                "checklist_id": props.get("checklistId") or "",
            }
            # Private keys are TLS material. A closed keystore is not. A file-key secret is not.
            if props.get("keyUsage"):
                row["key_usage"] = props["keyUsage"]
            elif row["key_type"] == "ASYMMETRIC":
                row["key_usage"] = "TLS"
            if length is not None:
                row["key_length"] = length
            rows.append(_present(row))
        elif item.get("type") == "library" or kind == "library" or asset_kind == "code-asset":
            rows.append(
                _present(
                    {
                        **shared,
                        "category": "code-asset",
                        "code_location": name,
                        "file_path": props.get("sourcePath") or name,
                        "function_name": props.get("functionName") or "",
                        "algorithm": props.get("algorithm") or str(item.get("version") or ""),
                        "language": props.get("language") or "",
                        "purpose": props.get("purpose") or "",
                        "checklist_id": props.get("checklistId") or "",
                    }
                )
            )
    return rows + legacy_config


def run_ssh(host: str, user: str, port: int, password: str, key_filename: str, known_hosts: str, script: str, use_sudo: bool, sudo_password: str, timeout: int) -> str:
    """Run the collector over one SSH session."""
    try:
        import paramiko
    except ImportError as exc:
        raise RuntimeError("paramiko is required for SSH password login. Install it with pip install paramiko") from exc
    client = paramiko.SSHClient()
    if known_hosts:
        client.load_host_keys(known_hosts)
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
    else:
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=host,
        port=port,
        username=user,
        password=password or None,
        key_filename=key_filename or None,
        timeout=timeout,
        allow_agent=True,
        look_for_keys=not password,
    )
    try:
        stdin, stdout, stderr = client.exec_command(remote_command(use_sudo, sudo_password), timeout=timeout)
        if use_sudo and sudo_password:
            stdin.write(sudo_password + "\n")
        stdin.write(script)
        stdin.flush()
        stdin.channel.shutdown_write()
        output = stdout.read().decode("utf-8", errors="replace")
        error = stderr.read().decode("utf-8", errors="replace")
    finally:
        client.close()
    output = _redact(output, [password, sudo_password])
    error = _redact(error, [password, sudo_password])
    if "##END assets##" not in output:
        detail = error.strip().splitlines()[-1] if error.strip() else "collector produced no asset section"
        raise RuntimeError(detail)
    return output


def self_test() -> int:
    """Build a CBOM from a fixed transcript and check the uploaded fields."""
    merged: dict[str, str] = {}
    _merge_defaults(
        merged,
        "mariadbd would have been started with the following arguments:\n"
        "--datadir=/var/lib/mysql --ssl-cipher=HIGH:!aNULL:!MD5:!3DES --tls-version=TLSv1.2,TLSv1.3 "
        "--ssl-cert=/etc/my.cnf.d/mariadb-certs/server-cert.pem\n",
    )
    if merged.get("tls_version") != "TLSv1.2,TLSv1.3" or merged.get("ssl_cipher") != "HIGH:!aNULL:!MD5:!3DES":
        print("effective tls_version or ssl_cipher was not read")
        return 1
    option_evidence = evidence_from_transcript(
        """
##BEGIN defaults##
--tls-version=TLSv1.2,TLSv1.3 --ssl-cipher=HIGH:!aNULL:!MD5:!3DES
##END defaults##
##BEGIN variables##
port	3306
##END variables##
##BEGIN listener##
LISTEN 0 80 *:3306
##END listener##
""",
        "db.example",
    )
    option_doc = build_upload_cbom(option_evidence, "db.example")
    option_refs = {item.get("bom-ref") for item in option_doc["components"]}
    if "protocol:TLSv1.2" not in option_refs or "protocol:TLSv1.3" not in option_refs:
        print("tls_version did not become protocol components")
        return 1
    if "cipher-suite:HIGH:!aNULL:!MD5:!3DES" in option_refs:
        print("OpenSSL expression was incorrectly emitted as a cipher-suite component")
        return 1
    if _component_props(option_doc["metadata"]["component"]).get("mariadb:sslCipherExpression") != "HIGH:!aNULL:!MD5:!3DES":
        print("original cipher expression audit evidence was dropped")
        return 1
    discovery = discovery_from_cbom(option_doc)
    if any(row.get("category") == "cipher" for row in discovery):
        print("unresolved expression must not create cipher rows")
        return 1
    if not any(row.get("cipher_type") == "protocol" and row.get("tls_version") == "TLSv1.2" for row in discovery):
        print("discovery array is missing TLS")
        return 1
    # Preserve the expression as configuration evidence, never a suite name.
    if any(row.get("cipher_suite") == "HIGH:!aNULL:!MD5:!3DES" for row in discovery):
        print("non-IANA cipher shorthand leaked into discovery cipher_suite field")
        return 1
    if not any(row.get("category") == "tls-configuration" and row.get("configured_value") == "HIGH:!aNULL:!MD5:!3DES" for row in discovery):
        print("cipher configuration audit row was dropped")
        return 1
    if not any(row.get("category") == "it-asset" and row.get("hostname") == "db.example" for row in discovery):
        print("discovery array is missing the host")
        return 1
    if "algorithm:MD5" in option_refs or "algorithm:3DES" in option_refs:
        print("excluded cipher was recorded as enabled")
        return 1
    transcript = """
##BEGIN version##
mariadbd  Ver 10.11.6-MariaDB
##END version##
##BEGIN variables##
tls_version	TLSv1.2,TLSv1.3
ssl_cipher	ECDHE-RSA-AES256-GCM-SHA384
tls_ciphersuites	TLS_AES_256_GCM_SHA384
have_ssl	YES
version_ssl_library	OpenSSL 3.0.7
port	3306
innodb_encrypt_tables	ON
file_key_management_filename	/etc/my.cnf.d/keys.txt
file_key_management_encryption_algorithm	AES_CBC
##END variables##
##BEGIN cert##
path=/etc/my.cnf.d/server.crt
subject=CN=db
issuer=CN=ca
serial=01
notBefore=Oct  6 00:00:00 2026 GMT
notAfter=Oct  6 00:00:00 2027 GMT
fingerprint=AA:BB
pubkey=rsaEncryption
signature=sha256WithRSAEncryption
bits=2048
ca=false
##END cert##
##BEGIN key##
path=/etc/my.cnf.d/server.key
algorithm=RSA
bits=2048
owner=mysql
mode=640
##END key##
##BEGIN routine##
app	store_card	AES_ENCRYPT
##END routine##
##BEGIN plugin##
file_key_management	ACTIVE	ENCRYPTION	file_key_management.so
##END plugin##
##BEGIN account##
mysql_native_password	2
##END account##
##BEGIN library##
libssl.so.3 => /lib64/libssl.so.3
##END library##
##BEGIN listener##
LISTEN 0 80 *:3306
##END listener##
"""
    evidence = evidence_from_transcript(transcript, "db.example")
    nested = evidence_from_transcript(
        """
##BEGIN assets##
##BEGIN cert##
path=/tmp/nested.crt
subject=CN=nested
issuer=CN=ca
serial=02
pubkey=rsaEncryption
signature=sha256WithRSAEncryption
bits=2048
##END cert##
##BEGIN key##
path=/tmp/nested.key
algorithm=RSA
bits=2048
##END key##
##END assets##
##BEGIN variables##
tls_version	TLSv1.2
port	3306
##END variables##
""",
        "nested.example",
    )
    if not nested["certificates"] or nested["certificates"][0]["path"] != "/tmp/nested.crt":
        print("certificate block nested in the asset scan was dropped")
        return 1
    if not nested["private_keys"]:
        print("key block nested in the asset scan was dropped")
        return 1
    if _port({"listeners": ["LISTEN 0 80 *:3306"]}) != "3306":
        print("backlog 80 was treated as the MariaDB port")
        return 1
    document = build_upload_cbom(evidence, "db.example")
    refs = {item.get("bom-ref") for item in document["components"]}
    required = {
        "certificate:/etc/my.cnf.d/server.crt",
        "key:/etc/my.cnf.d/server.key",
        "protocol:TLSv1.2",
        "protocol:TLSv1.3",
        "cipher-suite:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
        "cipher-suite:TLS_AES_256_GCM_SHA384",
        "code:app.store_card:AES_ENCRYPT",
        "code:file_key_management.so:file_key_management",
        "algorithm:AES-256",
        "algorithm:RSA",
        "secret-key:/etc/my.cnf.d/keys.txt",
    }
    missing = sorted(required - refs)
    if missing:
        print("missing " + ", ".join(missing))
        return 1
    encoded = json.dumps(document)
    if "PRIVATE KEY" in encoded or '"vendor"' in encoded:
        print("private key material or vendor field in CBOM")
        return 1
    full = discovery_from_cbom(document)
    if not any(row.get("certificate_serial_number") for row in full if row.get("category") == "certificate"):
        print("discovery certificate is missing certificate_serial_number")
        return 1
    server_cert = next(row for row in full if row.get("category") == "certificate" and row.get("file_path") == "/etc/my.cnf.d/server.crt")
    if server_cert.get("key_length") != 2048 or server_cert.get("hashing_algorithm") != "sha256WithRSAEncryption":
        print("certificate key length or signature algorithm was dropped")
        return 1
    if server_cert.get("is_ca_certificate") is not False or server_cert.get("san_raw"):
        print("certificate CA flag or SAN was invented")
        return 1
    if not any(row.get("code_location") == "libssl.so.3" for row in full):
        print("discovery array is missing the library")
        return 1
    if "mysql://db.example:3306" not in encoded or "mysql://db.example:80" in encoded:
        print("service port was taken from the ss backlog")
        return 1
    it_row = next(row for row in full if row.get("category") == "it-asset")
    if it_row.get("uri") != "db.example:3306" or it_row.get("asset_type") != "Database":
        print("it asset uri or type changed")
        return 1
    if it_row.get("protocol") != "TLS" or it_row.get("port") != "3306" or it_row.get("asset_subtype") != "MariaDB":
        print("it asset protocol, port, or subtype was not read from the host")
        return 1
    if it_row.get("ip"):
        print("it asset ip was invented for a hostname")
        return 1
    address_evidence = evidence_from_transcript(
        """
##BEGIN version##
mariadbd  Ver 10.11.6-MariaDB
##END version##
##BEGIN variables##
have_ssl	NO
port	3306
bind_address	0.0.0.0
##END variables##
##BEGIN listener##
tcp LISTEN 0 80 0.0.0.0:3306
##END listener##
##BEGIN address##
10.9.8.7
2: eth0    inet 10.9.8.7/24 brd 10.9.8.255 scope global eth0
##END address##
""",
        "db.example",
    )
    address_rows = discovery_from_cbom(build_upload_cbom(address_evidence, "db.example"))
    address_it = next(row for row in address_rows if row.get("category") == "it-asset")
    if address_it.get("ip") != "10.9.8.7" or address_it.get("protocol") != "TCP":
        print("host address or listener protocol was not read")
        return 1
    if address_it.get("asset_subtype") != "MariaDB" or "10.9.8.255" == address_it.get("ip"):
        print("subtype or broadcast address was wrong")
        return 1
    ip_evidence = evidence_from_transcript(
        """
##BEGIN variables##
port	3307
have_ssl	DISABLED
##END variables##
##BEGIN listener##
tcp LISTEN 0 80 10.1.2.3:3307
##END listener##
""",
        "10.1.2.3",
    )
    ip_rows = discovery_from_cbom(build_upload_cbom(ip_evidence, "10.1.2.3"))
    ip_it = next(row for row in ip_rows if row.get("category") == "it-asset")
    if ip_it.get("uri") != "10.1.2.3:3307" or ip_it.get("ip") != "10.1.2.3" or ip_it.get("protocol") != "TCP":
        print("ssh target address was not used")
        return 1
    if ip_it.get("asset_subtype") or ip_it.get("mission_criticality") or ip_it.get("owner"):
        print("unset profile or subtype was filled in")
        return 1
    if len(document["components"]) != 20:
        print("component count changed")
        return 1
    symmetric = [row for row in full if row.get("category") == "key" and row.get("key_type") == "SYMMETRIC"]
    asymmetric = [row for row in full if row.get("category") == "key" and row.get("key_type") == "ASYMMETRIC"]
    if len(symmetric) != 1 or symmetric[0].get("file_path") != "/etc/my.cnf.d/keys.txt":
        print("file key management key was not a symmetric key row")
        return 1
    sym = symmetric[0]
    if sym.get("key_algorithm") != "AES-CBC" or sym.get("key_state") != "ACTIVE":
        print("symmetric key algorithm or state was dropped")
        return 1
    if "key_length" in sym or sym.get("key_usage"):
        print("symmetric key invented a length or a TLS usage")
        return 1
    if sym.get("public_hash_key_value") != "/etc/my.cnf.d/keys.txt":
        print("symmetric key identity was not the path")
        return 1
    if "BEGIN" in json.dumps(sym) or "PRIVATE KEY" in json.dumps(sym):
        print("symmetric key row contains key material")
        return 1
    if len(asymmetric) != 1 or asymmetric[0].get("file_path") != "/etc/my.cnf.d/server.key":
        print("asymmetric private key row was dropped")
        return 1
    if asymmetric[0].get("key_usage") != "TLS" or asymmetric[0].get("key_length") != 2048 or asymmetric[0].get("key_type") != "ASYMMETRIC":
        print("asymmetric key length or usage changed")
        return 1
    if any(row.get("category") == "key" and row.get("file_path") == "innodb_encrypt_tables" for row in full):
        print("innodb encryption was invented as a key")
        return 1
    if not any(row.get("category") == "algorithm" and row.get("name") == "AES-256" for row in full):
        print("AES-256 algorithm row was dropped")
        return 1
    file_key_only = evidence_from_transcript(
        """
##BEGIN defaults##
--file-key-management-filename=/etc/mysql/rest.keys --file-key-management-encryption-algorithm=AES_CTR --file-key-management-filekey=not-collected
##END defaults##
##BEGIN variables##
port	3306
##END variables##
##BEGIN listener##
LISTEN 0 80 *:3306
##END listener##
""",
        "db.example",
    )
    if file_key_only.get("file_key", {}).get("path") != "/etc/mysql/rest.keys":
        print("file key path in the server options was dropped")
        return 1
    if file_key_only.get("file_key_algorithm") != "AES_CTR":
        print("file key algorithm in the server options was dropped")
        return 1
    if "not-collected" in json.dumps(file_key_only):
        print("file key password was collected")
        return 1
    file_rows = discovery_from_cbom(build_upload_cbom(file_key_only, "db.example"))
    file_sym = [row for row in file_rows if row.get("key_type") == "SYMMETRIC"]
    if (
        len(file_sym) != 1
        or file_sym[0].get("file_path") != "/etc/mysql/rest.keys"
        or file_sym[0].get("key_algorithm") != "AES-CTR"
        or file_sym[0].get("key_usage")
        or "key_length" in file_sym[0]
        or "not-collected" in json.dumps(file_sym)
    ):
        print("configured file key did not stay metadata")
        return 1
    with tempfile.TemporaryDirectory() as scratch:
        key_dir = Path(scratch) / "mariadb-certs"
        key_dir.mkdir()
        key_file = key_dir / "sym-key.txt"
        key_file.write_text("1;aabb\n2;ccdd\nnot-a-key\n", encoding="utf-8")
        start = _REMOTE.index("emit_file_key_ids() {")
        end = _REMOTE.index("\nemit_key_file() {")
        scan = subprocess.run(
            ["bash", "-c", _REMOTE[start:end] + "\nemit_file_key_ids \"$1\"\n", "bash", str(key_file)],
            capture_output=True,
            text=True,
            check=False,
        )
        scanned = scan.stdout
        if scan.returncode != 0 or "aabb" in scanned or "ccdd" in scanned or "1;aabb" in scanned:
            print("file key scan wrote key material")
            return 1
        if scanned.count("id=1") != 1 or scanned.count("id=2") != 1 or str(key_file) not in scanned:
            print("file key scan did not record one id per line")
            return 1
        id_rows = discovery_from_cbom(build_upload_cbom(evidence_from_transcript(scanned, "db.example"), "db.example"))
        id_keys = [row for row in id_rows if row.get("key_type") == "SYMMETRIC"]
        if len(id_keys) != 2:
            print("scanned file key ids were not symmetric rows")
            return 1
        by_id = {row.get("key_id"): row for row in id_keys}
        if set(by_id) != {"1", "2"}:
            print("scanned file key ids were dropped")
            return 1
        for row in id_keys:
            if row.get("file_path") != str(key_file) or row.get("key_state") != "ACTIVE" or row.get("key_algorithm") or "key_length" in row:
                print("scanned file key row invented an algorithm or a length")
                return 1
            if row.get("public_hash_key_value") != row.get("key_id"):
                print("scanned file key identity was not the key id")
                return 1
        with_algorithm = scanned + "\n##BEGIN variables##\nfile_key_management_encryption_algorithm\tAES_CTR\nport\t3306\n##END variables##\n"
        alg_rows = discovery_from_cbom(build_upload_cbom(evidence_from_transcript(with_algorithm, "db.example"), "db.example"))
        alg_keys = [row for row in alg_rows if row.get("key_type") == "SYMMETRIC"]
        if len(alg_keys) != 2 or any(row.get("key_algorithm") != "AES-CTR" for row in alg_keys):
            print("file key algorithm was not kept on the scanned ids")
            return 1
        leaked = json.dumps({"scan": scanned, "rows": id_rows, "algorithm_rows": alg_rows})
        if "aabb" in leaked or "ccdd" in leaked:
            print("file key hex was written into the discovery output")
            return 1
        poisoned = evidence_from_transcript(
            """
##BEGIN filekey##
path=/etc/my.cnf.d/mariadb-certs/sym-key.txt
id=1
material=1;aabb
##END filekey##
##BEGIN variables##
port	3306
##END variables##
""",
            "db.example",
        )
        if "aabb" in json.dumps(poisoned):
            print("file key hex was copied out of an extra field")
            return 1
        poisoned_doc = build_upload_cbom(poisoned, "db.example")
        if "aabb" in json.dumps(poisoned_doc):
            print("file key hex was written into the CBOM")
            return 1
    try:
        _reject_key_material("1;aabb")
    except RuntimeError as exc:
        if "aabb" in str(exc):
            print("key material refusal leaked the hex")
            return 1
    else:
        print("file key hex was accepted")
        return 1
    with tempfile.TemporaryDirectory() as scratch:
        work = Path(scratch)
        cert_pem = work / "server.pem"
        cert_der = work / "server.der"
        bundle = work / "server.p7b"
        locked = work / "locked.p12"
        opened = work / "opened.p12"
        openssh = work / "server_openssh"
        subprocess.run(
            [
                "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(work / "server.key"), "-out", str(cert_pem),
                "-days", "1", "-subj", "/CN=fixture",
                "-addext", "subjectAltName=DNS:db.example,IP:10.1.2.3",
                "-addext", "basicConstraints=critical,CA:FALSE",
            ],
            check=True, capture_output=True, text=True,
        )
        subprocess.run(["openssl", "x509", "-in", str(cert_pem), "-outform", "DER", "-out", str(cert_der)], check=True, capture_output=True)
        subprocess.run(["openssl", "crl2pkcs7", "-nocrl", "-certfile", str(cert_pem), "-out", str(bundle)], check=True, capture_output=True)
        subprocess.run(
            ["openssl", "pkcs12", "-export", "-in", str(cert_pem), "-inkey", str(work / "server.key"), "-out", str(opened), "-passout", "pass:changeit"],
            check=True, capture_output=True,
        )
        subprocess.run(
            ["openssl", "pkcs12", "-export", "-in", str(cert_pem), "-inkey", str(work / "server.key"), "-out", str(locked), "-passout", "pass:secret-store"],
            check=True, capture_output=True,
        )
        subprocess.run(["ssh-keygen", "-t", "ed25519", "-f", str(openssh), "-N", "", "-q"], check=True, capture_output=True)
        start = _REMOTE.index("emit_cert_pem() {")
        end = _REMOTE.index('echo "##BEGIN assets##"')
        runner = _REMOTE[start:end] + """
consider_asset "$1"
"""
        def scan(path: Path) -> str:
            result = subprocess.run(["bash", "-c", runner, "bash", str(path)], capture_output=True, text=True, check=False)
            if result.returncode != 0:
                print("asset scan failed for " + path.name)
                return ""
            return result.stdout
        der_out = scan(cert_der)
        p7_out = scan(bundle)
        store_out = scan(opened)
        locked_out = scan(locked)
        ssh_out = scan(openssh)
        combined = "\n".join([der_out, p7_out, store_out, locked_out, ssh_out])
        key_body = (work / "server.key").read_text(encoding="utf-8")
        if "PRIVATE KEY" in combined or "-----BEGIN " in combined or "secret-store" in combined or "changeit" in combined:
            print("opened file wrote key material or a store password")
            return 1
        if key_body.split("-----BEGIN ", 1)[-1][:24] in combined:
            print("private key body was copied into the scan")
            return 1
        if "subject=" not in der_out or "DNS:db.example" not in der_out or "bits=" not in der_out:
            print("DER certificate metadata was not recorded")
            return 1
        if "subject=" not in p7_out:
            print("PKCS#7 certificate was not recorded")
            return 1
        if "subject=" not in store_out or "#" not in store_out:
            print("keystore certificate was not recorded")
            return 1
        if "usage=KEYSTORE" not in locked_out or "algorithm=UNKNOWN" not in locked_out:
            print("locked keystore was opened or dropped")
            return 1
        if "algorithm=ED25519" not in ssh_out or "PRIVATE KEY" in ssh_out:
            print("OpenSSH private key metadata was not recorded")
            return 1
        parsed = evidence_from_transcript(der_out + "\n##BEGIN variables##\nport\t3306\nhave_ssl\tYES\n##END variables##\n", "db.example")
        parsed_rows = discovery_from_cbom(build_upload_cbom(parsed, "db.example"))
        parsed_cert = next(row for row in parsed_rows if row.get("category") == "certificate")
        if parsed_cert.get("key_length") != 2048 or parsed_cert.get("is_ca_certificate") is not False:
            print("DER certificate length or CA flag was dropped")
            return 1
        if "DNS:db.example" not in str(parsed_cert.get("san_raw")) or "sha256WithRSAEncryption" not in str(parsed_cert.get("hashing_algorithm")):
            print("DER certificate SAN or signature was dropped")
            return 1
        if "BEGIN" in json.dumps(parsed_rows):
            print("DER discovery row contains a PEM block")
            return 1
    print("self-test ok components={}".format(len(document["components"])))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Collect MariaDB crypto assets over SSH and write a CycloneDX CBOM")
    parser.add_argument("--host")
    parser.add_argument("--user", default="root")
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--password", default=os.environ.get("MARIADB_SSH_PASSWORD", ""))
    parser.add_argument("--key", default="", help="SSH private key path")
    parser.add_argument("--known-hosts", default="")
    parser.add_argument("--sudo", action="store_true")
    parser.add_argument("--sudo-password", default=os.environ.get("MARIADB_SUDO_PASSWORD", ""))
    parser.add_argument("--mysql-password", default=os.environ.get("MARIADB_MYSQL_PASSWORD", ""))
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--output", type=Path, help="CycloneDX CBOM path. Default: mariadb-cbom-<host>.json")
    parser.add_argument("--discovery-output", type=Path, help="Optional flat JSON array for transform_discover.json")
    parser.add_argument("--from-cbom", type=Path, help="Add the IT asset and dependency links to an existing CycloneDX CBOM")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        return self_test()
    if args.from_cbom:
        document = attach_it_asset(json.loads(args.from_cbom.read_text(encoding="utf-8")))
        destination = args.output or Path("mariadb-cbom.json")
        destination.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")
        print(f"wrote {destination} components={len(document.get('components') or [])}")
        return 0
    if not args.host:
        parser.error("--host is required")
    script = render_remote(args.mysql_password)
    try:
        transcript = run_ssh(
            args.host,
            args.user,
            args.port,
            args.password,
            args.key,
            args.known_hosts,
            script,
            args.sudo or bool(args.sudo_password),
            args.sudo_password,
            args.timeout,
        )
    except RuntimeError as exc:
        print(_redact(str(exc), [args.password, args.sudo_password, args.mysql_password]), file=sys.stderr)
        return 1
    evidence = evidence_from_transcript(transcript, args.host)
    document = build_upload_cbom(evidence, args.host)
    destination = args.output or Path(f"mariadb-cbom-{args.host.replace(':', '_')}.json")
    destination.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")
    if args.discovery_output:
        args.discovery_output.write_text(json.dumps(discovery_from_cbom(document), indent=2) + "\n", encoding="utf-8")
    kinds = sorted({str(item.get("bom-ref", "")).split(":", 1)[0] for item in document["components"]})
    paths = evidence.get("ssl_paths") or {}
    trace = evidence.get("trace") or {}
    print(
        "wrote {dest} components={count} kinds={kinds} certificates={certs} keys={keys} tls={tls} ciphers={ciphers}".format(
            dest=destination,
            count=len(document["components"]),
            kinds=",".join(kinds),
            certs=len(evidence.get("certificates") or []),
            keys=len(evidence.get("private_keys") or []),
            tls=paths.get("tls_version") or "-",
            ciphers=paths.get("ssl_cipher") or "-",
        )
    )
    if not evidence.get("certificates"):
        print(
            "no certificate opened. datadir={datadir} ssl_cert={cert} ssl_key={key}".format(
                datadir=trace.get("datadir", ""),
                cert=paths.get("ssl_cert") or "(empty)",
                key=paths.get("ssl_key") or "(empty)",
            ),
            file=sys.stderr,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
