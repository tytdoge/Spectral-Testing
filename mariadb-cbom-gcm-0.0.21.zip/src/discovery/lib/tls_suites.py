"""Canonical TLS suites and a read-only resolver executed on the MariaDB host.

No worker-side expansion of a remote configuration is performed. The target
must report its OpenSSL backend version, which is compared with the target CLI.
The result describes configured/supported suites, not an active handshake scan.
"""
import json
import re

from tls_cipher_catalog import IANA_NAMES, NAME_MAP, TLS13_NAMES

VERSION_NAMES = {"TLSv1": "TLSv1.0", "TLSv1.0": "TLSv1.0", "TLSv1.1": "TLSv1.1", "TLSv1.2": "TLSv1.2", "TLSv1.3": "TLSv1.3"}


def canonical_name(value):
    return NAME_MAP.get(str(value or "").strip(), "")


def canonical_names(values):
    return sorted({canonical_name(value) for value in values if canonical_name(value)})


def parse_expansions(blocks):
    protocols = {}
    diagnostics = []
    records = []
    for block in blocks:
        header, _, listing = block.partition("##SUITES##")
        record = {}
        for line in header.splitlines():
            key, separator, value = line.partition("=")
            if separator:
                record[key.strip()] = value.strip()
        version = VERSION_NAMES.get(record.get("version", ""), "")
        record["version"] = version
        status = record.get("status", "unresolved")
        if record.get("input_source") == "mariadb_ssl_cipher_list":
            diagnostics.append((version or "TLS") + ":reported_cipher_list_may_be_truncated")
        names = []
        unknown = []
        if status == "resolved" and version:
            for line in listing.splitlines():
                parts = line.split()
                if len(parts) >= 4 and parts[1] == "-" and re.match(r"^(?:TLS|SSL)v", parts[3]):
                    token = parts[0]
                elif len(parts) >= 2 and re.match(r"^(?:TLS|SSL)v", parts[1]):
                    token = parts[0]
                else:
                    continue
                name = canonical_name(token)
                if not name:
                    unknown.append(token)
                elif (name in TLS13_NAMES) == (version == "TLSv1.3"):
                    names.append(name)
            names = sorted(set(names))
            if unknown:
                diagnostics.append(version + ":unrecognised_suite_names")
            if not names:
                status = "unresolved"
                record["reason"] = "no_known_supported_suites"
            else:
                protocols.setdefault(version, []).extend(names)
        if status != "resolved":
            diagnostics.append((version or "TLS") + ":" + record.get("reason", status))
        record["status"] = status
        record["suites"] = names
        records.append(record)
    protocols = {version: sorted(set(names)) for version, names in protocols.items()}
    if not records:
        status = "unresolved"
        diagnostics.append("TLS:suite_expansion_not_collected")
    elif all(record["status"] == "disabled" for record in records):
        status = "disabled"
    elif protocols and not diagnostics:
        status = "resolved"
    elif protocols:
        status = "partial"
    else:
        status = "unresolved"
    return {"status": status, "protocols": protocols, "diagnostics": sorted(set(diagnostics)), "records": records}


def suites_from_evidence(evidence):
    """Use collected per-version results, or exact concrete names in offline input.

    A historical OpenSSL expression cannot be expanded on this machine. Exact
    concrete names can be normalised without claiming a target runtime probe.
    """
    resolution = evidence.get("tls_suite_resolution") or {}
    if resolution.get("records"):
        return {
            version: canonical_names(names)
            for version, names in resolution.get("protocols", {}).items()
            if version in VERSION_NAMES and canonical_names(names)
        }
    versions = {VERSION_NAMES.get(str(value).strip()) for value in evidence.get("tls_versions", [])}
    result = {}
    legacy = [name for name in canonical_names(evidence.get("tls12_suites", [])) if name not in TLS13_NAMES]
    modern = [name for name in canonical_names(evidence.get("tls13_suites", [])) if name in TLS13_NAMES]
    if legacy and "TLSv1.2" in versions:
        result["TLSv1.2"] = legacy
    if modern and "TLSv1.3" in versions:
        result["TLSv1.3"] = modern
    return result


_REMOTE = r'''
# MDB_TLS_RESOLUTION_BEGIN
mdb_tls_option() {
  local requested="$1" answer
  answer=$(printf '%s\n' "$MDB_TLS_VALUES" | awk -F '\t' -v key="$requested" '$1==key {print substr($0,index($0,"\t")+1); exit}')
  if [ -n "$answer" ]; then printf '%s\n' "$answer"; return; fi
  printf '%s\n' "$MDB_TLS_DEFAULTS" | awk -v key="$requested" '
    { line=$0; sub(/^--/,"",line); pos=index(line,"="); if (!pos) next;
      name=substr(line,1,pos-1); gsub(/-/,"_",name);
      if (name==key) {value=substr(line,pos+1); gsub(/^["\047]|["\047]$/,"",value); if(value!=""){print value; exit}} }'
}
mdb_cipher_expression() {
  printf '%s\n' "$1" | awk 'BEGIN {__REVERSE_MAP__}
    { count=split($0,tokens,":"); for(i=1;i<=count;i++) {
        token=tokens[i]; prefix="";
        while(substr(token,1,1) ~ /[!+-]/) {prefix=prefix substr(token,1,1); token=substr(token,2)}
        if(token in alias) token=alias[token];
        printf "%s%s%s", (i>1?":":""),prefix,token;
      } print ""; }'
}
mdb_server_cipher_list() {
  printf '%s\n' "$1" | awk -v modern="$2" 'BEGIN {__NAME_MAP__ __TLS13_MAP__}
    { count=split($0,tokens,":"); delimiter="";
      for(i=1;i<=count;i++) {token=tokens[i]; gsub(/^[[:space:]]+|[[:space:]]+$/,"",token);
        if(!(token in canonical)) continue;
        name=canonical[token]; ismodern=(name in tls13);
        if(ismodern==modern){printf "%s%s",delimiter,name; delimiter=":"}
      } print ""; }'
}
mdb_tls_result() {
  printf '##BEGIN tls_cipher_result##\nversion=%s\nstatus=%s\nreason=%s\ninput_source=%s\n' "$1" "$2" "$3" "$4"
  printf 'backend_version=%s\ncli_version=%s\nserver_version=%s\nscope=target_configured_supported\n' "$MDB_BACKEND_TLS" "$MDB_CLI_TLS" "$MDB_SERVER_TLS_VERSION"
  printf '##SUITES##\n%s\n##END tls_cipher_result##\n' "$5"
}
mdb_resolve_tls() {
  local versions backend_number cli_number have_ssl server_list version flag expression source output rc combined_backend raw_cipher counterpart
  MDB_BACKEND_TLS=$(mdb_tls_option version_ssl_library)
  MDB_CLI_TLS=$(openssl version 2>/dev/null | head -n 1)
  MDB_SERVER_TLS_VERSION=$(mdb_tls_option version)
  combined_backend=0
  # Verified release-specific viosslfactories.c behavior:
  # 10.5.29 invokes both setters; 10.11.6 invokes legacy only if modern fails.
  # A setter that was not successfully applied retains its library defaults.
  case "$MDB_SERVER_TLS_VERSION" in
    10.5.29-MariaDB*) combined_backend=1;;
    10.11.6-MariaDB*) combined_backend=2;;
  esac
  have_ssl=$(mdb_tls_option have_ssl)
  case "$have_ssl" in NO|OFF|DISABLED|FALSE|0) mdb_tls_result '' disabled tls_disabled '' ''; return;; esac
  backend_number=$(printf '%s\n' "$MDB_BACKEND_TLS" | awk '/^OpenSSL [0-9]/ {print $2; exit}')
  cli_number=$(printf '%s\n' "$MDB_CLI_TLS" | sed -n 's/.*(Library: OpenSSL \([^ )]*\).*/\1/p')
  if [ -z "$cli_number" ]; then cli_number=$(printf '%s\n' "$MDB_CLI_TLS" | awk '/^OpenSSL [0-9]/ {print $2; exit}'); fi
  if [ -z "$backend_number" ]; then mdb_tls_result '' unresolved mariadb_openssl_backend_unconfirmed '' ''; return; fi
  if [ -z "$cli_number" ]; then mdb_tls_result '' unresolved target_openssl_unavailable '' ''; return; fi
  if [ "$backend_number" != "$cli_number" ]; then mdb_tls_result '' unresolved openssl_version_mismatch '' ''; return; fi
  versions=$(mdb_tls_option tls_version)
  if [ -z "$versions" ]; then mdb_tls_result '' unresolved tls_versions_unknown '' ''; return; fi
  server_list=$(printf '%s\n' "$MDB_TLS_STATUS" | awk -F '\t' 'tolower($1)=="ssl_cipher_list" {print substr($0,index($0,"\t")+1); exit}')
  raw_cipher=$(mdb_tls_option ssl_cipher)
  local version_list
  IFS=',' read -r -a version_list <<< "$versions"
  for version in "${version_list[@]}"; do
    version=$(printf '%s' "$version" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    case "$version" in
      TLSv1|TLSv1.0) version=TLSv1.0; flag=-tls1;;
      TLSv1.1) flag=-tls1_1;;
      TLSv1.2) flag=-tls1_2;;
      TLSv1.3) flag=-tls1_3;;
      *) mdb_tls_result "$version" unresolved unsupported_protocol_version '' ''; continue;;
    esac
    if [ "$version" = TLSv1.3 ]; then
      expression=$(mdb_tls_option tls_ciphersuites); source=tls_ciphersuites
      if [ -z "$expression" ] && [ "$combined_backend" -gt 0 ]; then
        expression="$raw_cipher"; source=combined_ssl_cipher
      fi
    else
      expression="$raw_cipher"; source=ssl_cipher
      if [ "$combined_backend" -eq 2 ] && [ -n "$raw_cipher" ]; then
        counterpart=$(mdb_server_cipher_list "$raw_cipher" 1)
        if [ -n "$counterpart" ] && openssl ciphers -s -tls1_3 -ciphersuites "$raw_cipher" >/dev/null 2>&1; then
          expression=''; source=mariadb_default_legacy_after_tls13_selection
        fi
      fi
    fi
    if [ -z "$expression" ] && [ "$combined_backend" -gt 0 ]; then
      if [ "$source" != mariadb_default_legacy_after_tls13_selection ]; then source=mariadb_openssl_default; fi
    elif [ -z "$expression" ] && [ -n "$server_list" ]; then
      source=mariadb_ssl_cipher_list
      if [ "$version" = TLSv1.3 ]; then expression=$(mdb_server_cipher_list "$server_list" 1);
      else expression=$(mdb_server_cipher_list "$server_list" 0); fi
      if [ -z "$expression" ]; then mdb_tls_result "$version" unresolved cipher_configuration_unknown "$source" ''; continue; fi
    elif [ -z "$expression" ]; then
      mdb_tls_result "$version" unresolved cipher_configuration_unknown "$source" ''; continue
    fi
    local args
    args=(-v -s "$flag")
    if [ -n "$expression" ]; then
      if [ "$version" = TLSv1.3 ]; then args+=(-ciphersuites "$expression");
      else expression=$(mdb_cipher_expression "$expression"); args+=(-- "$expression"); fi
    fi
    output=$(openssl ciphers -stdname "${args[@]}" 2>&1); rc=$?
    if [ "$rc" -ne 0 ] && printf '%s\n' "$output" | grep -Eiq '(unknown|unrecognized|invalid).*(option|argument).*stdname|stdname.*(unknown|unrecognized)'; then
      output=$(openssl ciphers "${args[@]}" 2>&1); rc=$?
    fi
    if [ "$rc" -ne 0 ] && [ "$combined_backend" -gt 0 ]; then
      counterpart=''
      if [ "$version" = TLSv1.3 ] && [ "$source" = combined_ssl_cipher ]; then
        counterpart=$(mdb_cipher_expression "$raw_cipher")
        if openssl ciphers -s -tls1_2 -- "$counterpart" >/dev/null 2>&1; then
          output=$(openssl ciphers -stdname -v -s "$flag" 2>&1); rc=$?; source=mariadb_openssl_default_after_legacy_expression
        fi
      elif [ "$version" != TLSv1.3 ] && [ "$source" = ssl_cipher ]; then
        counterpart=$(mdb_server_cipher_list "$raw_cipher" 1)
        if [ -n "$counterpart" ] && openssl ciphers -s -tls1_3 -ciphersuites "$counterpart" >/dev/null 2>&1; then
          output=$(openssl ciphers -stdname -v -s "$flag" 2>&1); rc=$?; source=mariadb_openssl_default_after_tls13_names
        fi
      fi
    fi
    if [ "$rc" -eq 0 ]; then mdb_tls_result "$version" resolved '' "$source" "$output";
    else mdb_tls_result "$version" unresolved cipher_expansion_failed "$source" ''; fi
  done
}
mdb_resolve_tls
# MDB_TLS_RESOLUTION_END
'''


def render_remote_resolver():
    reverse = {iana: alias for alias, iana in NAME_MAP.items() if alias != iana}
    assignment = lambda name, key, value: name + "[" + json.dumps(key) + "]=" + json.dumps(value) + ";"
    names = "".join(assignment("canonical", key, value) for key, value in sorted(NAME_MAP.items()))
    aliases = "".join(assignment("alias", key, value) for key, value in sorted(reverse.items()))
    modern = "".join("tls13[" + json.dumps(value) + "]=1;" for value in sorted(TLS13_NAMES))
    return _REMOTE.replace("__NAME_MAP__", names).replace("__REVERSE_MAP__", aliases).replace("__TLS13_MAP__", modern)
